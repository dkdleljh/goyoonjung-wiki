# Watchdog Report (auto)

> Stable watchdog snapshot; volatile timer countdowns are omitted.

## Summary
- status: WARN
- warnings: 1

## Checks
| target | state | detail |
|---|---|---|
| goyoonjung-wiki-daily.timer | OK | listed |
| check_automation_health | WARN | "2026-11-01T17:50:00+09:00",   "age_hours": 0.05,   "source": "news/2026-11-01.md",   "recorded_result": "running",   "reason": "auto: daily update running",   "max_age_hours": 8 } |
