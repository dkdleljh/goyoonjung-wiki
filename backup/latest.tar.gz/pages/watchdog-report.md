# Watchdog Report (auto)

> Stable watchdog snapshot; volatile timer countdowns are omitted.

## Summary
- status: WARN
- warnings: 1

## Checks
| target | state | detail |
|---|---|---|
| goyoonjung-wiki-daily.timer | OK | listed |
| check_automation_health | WARN | "2026-11-03T00:02:00+09:00",   "age_hours": 0.06,   "source": "news/2026-11-03.md",   "recorded_result": "running",   "reason": "auto: daily update running",   "max_age_hours": 8 } |
