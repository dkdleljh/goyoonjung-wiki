# 🧾 인터뷰/기사 항목 템플릿

## 공식 링크
- (S) 기준(필모/작품): https://maa.co.kr/artists/go-younjung

## 출처
- pages/interviews.md


- 날짜: YYYY-MM-DD
- 매체:
- 제목:
- 링크:
- 상태: 공식확정 | 공식예고 | 보도(1차) | 보도(2차)
- id: (URL)
- 요약(3~5줄):
- 키워드:
