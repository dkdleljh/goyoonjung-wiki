# 🎬 이재, 곧 죽습니다 (TVING)

![이재 곧 죽습니다에서 이지수 역을 맡은 고윤정의 공식 장면 사진](https://dkdleljh.github.io/goyounjung/images/photos/work-deaths-game-640.webp)


## 기본 정보
- 작품: 이재, 곧 죽습니다
- 플랫폼/방송사: TVING
- 고윤정 역할: 이지수
- 비고: 특별출연 (근거: MAA)

## 공식 소개(요약)
- (보강 예정) TVING 공식 소개 문구를 기반으로 요약합니다.

## 관련 링크
- 공식 페이지(TVING): https://www.tving.com/contents/P001748996
## 공식 링크
- (S) TVING 공식 페이지: https://www.tving.com/contents/P001748996
- (S) 과거 소속사(MAA) 아티스트 프로필: https://maa.co.kr/artists/go-younjung


<!-- AUTO-CANDIDATES:START -->
## 관련 링크(자동 후보)

> 생성: 2026-10-18 14:23 (Asia/Seoul) — 키워드 매칭 기반 자동 후보이며, 최종 반영은 사람이 검토합니다.

### 전체 후보

- ['환혼' 고윤정 "이재욱, 키 크고 목소리 좋아..키스신 때 너무 떨렸다"](https://m.news.nate.com/view/20221221n37438)  _(출처: interviews.md)_
<!-- AUTO-CANDIDATES:END -->

## 링크 박스
- 공식 페이지(TVING): https://www.tving.com/contents/P001748996
## 공개일(근거)
- Part 1 공개: 2023-12-15 (근거: `pages/schedule.md`)

## 출처
- 과거 소속사(MAA) 아티스트 프로필: https://maa.co.kr/artists/go-younjung
