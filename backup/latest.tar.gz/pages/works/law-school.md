# 🎬 로스쿨 (JTBC)

![법정에 모인 로스쿨 출연진의 공식 홍보 이미지](https://dkdleljh.github.io/goyounjung/images/photos/work-law-school-640.webp)


## 기본 정보
- 작품: 로스쿨
- 방송사: JTBC
- 고윤정 역할: 전예슬
- 첫 방송: 2021-04-14 21:00 (근거: JTBC 1회 다시보기 페이지)

## 공식 소개(요약)
- JTBC 공식 홈페이지에서 프로그램 정보/영상/등장인물 소개 등을 제공.

## 관련 링크
- 공식 페이지(JTBC): https://tv.jtbc.co.kr/lawschool
- 등장인물 소개(JTBC): https://tv.jtbc.co.kr/cast/PR10011289/1

## 공식 링크
- https://tv.jtbc.co.kr/lawschool
- https://tv.jtbc.co.kr/cast/PR10011289/1


## 출처
- (S) 공식 링크: https://tv.jtbc.co.kr/lawschool
- (S) 공식 링크: https://tv.jtbc.co.kr/cast/PR10011289/1


<!-- AUTO-CANDIDATES:START -->
## 관련 링크(자동 후보)

> 생성: 2026-10-18 14:23 (Asia/Seoul) — 키워드 매칭 기반 자동 후보이며, 최종 반영은 사람이 검토합니다.

### 전체 후보

- [[인터뷰] 고윤정은 달린다 응원할게, 너 (디즈니+ ‘무빙’)](https://kstar.kbs.co.kr/list_view.html?idx=277651)  _(출처: interviews.md)_

- ['로스쿨' 고윤정, 진정성 가득한 열열.."특별한 작품"](https://www.starnewskorea.com/stview.php?no=2021061016204618571)  _(출처: interviews.md)_

- [[예습 메이킹] 전예슬 인터뷰 고윤정 실물 느낌 요약](https://entertain.daum.net/tv/5138294/video/418173622)  _(출처: interviews.md)_
<!-- AUTO-CANDIDATES:END -->

## 링크 박스
- 공식 페이지: https://tv.jtbc.co.kr/lawschool
- 등장인물: https://tv.jtbc.co.kr/cast/PR10011289/1
