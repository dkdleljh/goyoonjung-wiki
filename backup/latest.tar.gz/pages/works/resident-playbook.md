# 🎬 언젠가는 슬기로울 전공의생활 (tvN)

![흰 가운을 입고 나란히 서 있는 언젠가는 슬기로울 전공의생활의 고윤정과 동료 출연진](https://dkdleljh.github.io/goyounjung/images/photos/work-resident-playbook-640.webp)


## 기본 정보
- 작품: 언젠가는 슬기로울 전공의생활
- 플랫폼/방송사: tvN
- 고윤정 역할: 오이영

## 공식 소개(요약)
- (보강 예정) tvN 공식 소개 문구/시놉시스를 기반으로 요약합니다.

## 관련 링크
- 공식 페이지(tvN): https://tvn.cjenm.com/ko/resident-playbook/
- 1화(근거용, TVING): https://www.tving.com/contents/P001768976
## 공식 링크
- https://tvn.cjenm.com/ko/resident-playbook/
- https://www.tving.com/contents/P001768976
- https://www.youtube.com/watch?v=SIKJWldJHTU


<!-- AUTO-CANDIDATES:START -->
## 관련 링크(자동 후보)

> 생성: 2026-10-18 14:23 (Asia/Seoul) — 키워드 매칭 기반 자동 후보이며, 최종 반영은 사람이 검토합니다.

### 전체 후보

- [[인터뷰] 고윤정 “사랑해 주세요, 내가 당신을 사랑하듯이” (넷플릭스 ’이 사랑 통역 되나요?‘)](https://kstar.kbs.co.kr/list_view.html?idx=391146)  _(출처: interviews.md)_

- ['의사 오이영' 고윤정, “매 순간 값지고 소중했던 작품](https://kstar.kbs.co.kr/list_view.html?idx=362920)  _(출처: interviews.md)_

- [고윤정, 오이영으로 한 뼘 더 성장](https://kstar.kbs.co.kr/list_view.html?idx=363033)  _(출처: interviews.md)_

- [<언젠가는 슬기로울 전공의생활> 관련 보도(사진/스틸 포함 가능)](https://kstar.kbs.co.kr/list_view.html?idx=361830)  _(출처: appearances.md)_

- [<언젠가는 슬기로울 전공의생활> 관련 보도(사진/스틸 포함 가능)](https://kstar.kbs.co.kr/list_view.html?idx=362628)  _(출처: appearances.md)_

- [<언젠가는 슬기로울 전공의생활> 관련 보도(사진/스틸 포함 가능)](https://kstar.kbs.co.kr/list_view.html?idx=362734)  _(출처: appearances.md)_
<!-- AUTO-CANDIDATES:END -->

## 링크 박스
- 공식 페이지(스틸/정보): https://tvn.cjenm.com/ko/resident-playbook/
- 1화(방송일 근거): https://www.tving.com/contents/P001768976
## 공개/방영일(근거)
- 첫 방송: 2025-04-12 21:10
  - 근거: TVING(공식) 영상 설명란에 “TVING 4월 12일 공개” + 해시태그로 “밤9시10분첫방송” 표기
  - 링크: https://www.youtube.com/watch?v=SIKJWldJHTU
- 최종화/종영: 2025-05-18 21:20
  - 근거: tvN 프로그램 데이터 내 “5/18 [일] 밤 9:20 최종화 방송” 표기
- KBS연예 기사(보도 1차):
  - https://kstar.kbs.co.kr/list_view.html?idx=361830
  - https://kstar.kbs.co.kr/list_view.html?idx=362628
  - https://kstar.kbs.co.kr/list_view.html?idx=362734
  - https://kstar.kbs.co.kr/list_view.html?idx=362920
  - https://kstar.kbs.co.kr/list_view.html?idx=363033

## 출처
- 과거 소속사(MAA) 아티스트 프로필: https://maa.co.kr/artists/go-younjung
