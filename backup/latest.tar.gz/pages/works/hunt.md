# 🎬 헌트 (영화)

![이정재와 정우성을 배치한 영화 헌트의 공식 해외 포스터](https://dkdleljh.github.io/goyounjung/images/photos/work-hunt-640.webp)


## 기본 정보
- 작품: 헌트
- 구분: 영화
- 고윤정 역할: 조유정

## 공식 소개(요약)
- 배급사 공식 채널에서 예고편/홍보 영상을 공개.

## 관련 링크
- 공식 예고편(배급사/YouTube): https://www.youtube.com/watch?v=CSOb8gia_mg

## 공식 링크
- (S) 공식 예고편(배급/제작 공식 채널): https://www.youtube.com/watch?v=CSOb8gia_mg
- (S) 과거 소속사(MAA) 아티스트 프로필: https://maa.co.kr/artists/go-younjung


## 출처
- (S) 공식 링크: https://www.youtube.com/watch?v=CSOb8gia_mg


<!-- AUTO-CANDIDATES:START -->
## 관련 링크(자동 후보)

> 생성: 2026-10-24 04:30 (Asia/Seoul) — 키워드 매칭 기반 자동 후보이며, 최종 반영은 사람이 검토합니다.

### 자동 추천(S급 우선)

- ⭐ [<헌트>로 스크린에 데뷔하는 고윤정이 현장에서 가장 듣고 싶은 칭찬은?](https://www.esquirekorea.co.kr/article/68124)  _(출처: interviews.md)_



### 전체 후보

- [<헌트>로 스크린에 데뷔하는 고윤정이 현장에서 가장 듣고 싶은 칭찬은?](https://www.esquirekorea.co.kr/article/68124)  _(출처: interviews.md)_

- [[인터뷰] 고윤정은 달린다 응원할게, 너 (디즈니+ ‘무빙’)](https://kstar.kbs.co.kr/list_view.html?idx=277651)  _(출처: interviews.md)_

- [고윤정, '헌트'로 스크린 데뷔..이정재 "놀랍고 훌륭한 배우"](https://www.starnewskorea.com/stview.php?no=2022063010405847866)  _(출처: interviews.md)_

- ['헌트' 고윤정 "고문 연기, 허성태 덕분에 편안하게 촬영"](https://mydaily.co.kr/page/view/2022072719409407409)  _(출처: interviews.md)_

- ['더헌터' 고윤정 님 인터뷰](https://extmovie.com/movietalk/86419918)  _(출처: interviews.md)_

- [고윤정, 이정재·정우성 향한 ♥ 고백.."날 선택해줘서 감사"](https://www.starnewskorea.com/stview.php?no=2023043020331863820)  _(출처: interviews.md)_

- [영화 <헌트> 시사회(현장)](https://kstar.kbs.co.kr/list_view.html?idx=220920)  _(출처: appearances.md)_
<!-- AUTO-CANDIDATES:END -->

## 링크 박스
- 예고편/홍보(공식): https://www.youtube.com/watch?v=CSOb8gia_mg
- 시사회/현장(보도 1차): https://kstar.kbs.co.kr/list_view.html?idx=220920

## 개봉·배역 확인

- 개봉: 2022-08-10 — [KOFIC 작품 정보](https://m.koreanfilm.or.kr/eng/films/index/filmsView.jsp?movieCd=20211792)
- 고윤정의 조유정 역 — [한국영상자료원](https://www.koreafilm.or.kr/library/search/video/114983)
