# 🎬 사이코메트리 그녀석 (tvN)

![사이코메트리 그녀석 공식 포스터 속 박진영과 신예은](https://dkdleljh.github.io/goyounjung/images/photos/work-he-is-psychometric-459.webp)


## 기본 정보
- 작품: 사이코메트리 그녀석
- 플랫폼/방송사: tvN
- 고윤정 역할: 김소현
- 첫 방송: 2019-03-11 21:30 (근거: tvN DRAMA 공식 영상 설명란)

## 공식 소개(요약)
- (보강 예정) tvN 공식 소개 문구/시놉시스를 기반으로 요약합니다.

## 관련 링크
- 공식 페이지(tvN): https://tvn.cjenm.com/ko/heispsychometric/
- TVING 다시보기: https://www.tving.com/contents/P000820341
## 공식 링크
- https://tvn.cjenm.com/ko/heispsychometric/
- https://www.tving.com/contents/P000820341
- https://www.youtube.com/watch?v=JEnAnsSdLbQ
- https://tvn.cjenm.com/ko/heispsychometric/video/


<!-- AUTO-CANDIDATES:START -->
## 관련 링크(자동 후보)

> 생성: 2026-10-18 14:23 (Asia/Seoul) — 키워드 매칭 기반 자동 후보이며, 최종 반영은 사람이 검토합니다.

### 전체 후보

- [승승장구 고윤정... 매 작품이 ‘인생캐’!](https://kstar.kbs.co.kr/list_view.html?idx=391253)  _(출처: interviews.md)_

- [[인터뷰] 고윤정은 달린다 응원할게, 너 (디즈니+ ‘무빙’)](https://kstar.kbs.co.kr/list_view.html?idx=277651)  _(출처: interviews.md)_
<!-- AUTO-CANDIDATES:END -->

## 링크 박스
- 방송 정보(공식, tvN DRAMA / YouTube): https://www.youtube.com/watch?v=JEnAnsSdLbQ
- 공식 페이지(tvN): https://tvn.cjenm.com/ko/heispsychometric/
- 다시보기/정보(TVING): https://www.tving.com/contents/P000820341
- 예고편/클립(공식, tvN): https://tvn.cjenm.com/ko/heispsychometric/video/

## 출처
- 과거 소속사(MAA) 아티스트 프로필: https://maa.co.kr/artists/go-younjung
