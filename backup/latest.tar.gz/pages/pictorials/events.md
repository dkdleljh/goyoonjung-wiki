# 📸 사진/화보 — 행사/포토월/시상식 (링크 아카이브)

![샤넬 뷰티 관련 마리끌레르 영상 속 고윤정](https://dkdleljh.github.io/goyounjung/images/photos/chanel-720.webp)

## 템플릿
- 날짜: YYYY-MM-DD
- 구분: 제작발표회 | 시사회 | 포토월 | 시상식 | 행사 | 기타
- 행사명:
- 주최/플랫폼:
- 링크(공식/원문):
- 상태: 공식확정 | 공식예고 | 보도(1차) | 보도(2차)
- id: (URL)
- 메모: (공개된 정보만)

---

## 2026
- 날짜: 2026-01-14
- 구분: 제작발표회/포토타임
- 행사명: 넷플릭스 <이 사랑 통역 되나요?> 제작발표회
- 주최/플랫폼: Netflix / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=389846
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=389846
- 메모: 행사 사진/현장 기록이 포함될 수 있는 보도 링크.

- 날짜: 2026-01-05
- 구분: 기타(기사/스틸)
- 행사명: 넷플릭스 <이 사랑 통역 되나요?> 관련 보도(사진/스틸 포함 가능)
- 주최/플랫폼: Netflix / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=389107
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=389107

- 날짜: 2026-01-27
- 구분: 기타(인터뷰/스틸)
- 행사명: [인터뷰] 고윤정 “사랑해 주세요, 내가 당신을 사랑하듯이” (넷플릭스 ’이 사랑 통역 되나요?‘)
- 주최/플랫폼: Netflix / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=391146
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=391146

- 날짜: 2026-01-28
- 구분: 기타(기사/스틸)
- 행사명: (기사) 고윤정 커리어/작품 관련(사진 포함 가능)
- 주최/플랫폼: KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=391253
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=391253

## 2025
- 날짜: 2025-05-01
- 구분: 예능/홍보(영상)
- 행사명: 유 퀴즈 온 더 블럭 — 고윤정 출연 하이라이트(공식 업로드)
- 주최/플랫폼: tvN (YouTube)
- 링크(공식/원문): https://www.youtube.com/watch?v=TiTWX_KfEc0
- 상태: 공식확정
- id: https://www.youtube.com/watch?v=TiTWX_KfEc0
- 메모: 출연 하이라이트 영상. (사진보다는 영상)

- 날짜: 2025-05-09
- 구분: 유튜브(라이브 예고/공지)
- 행사명: 채널십오야 라이브 방송 출격(기사 기반 공지)
- 주최/플랫폼: 채널 십오야 / YTN Star
- 링크(공식/원문): https://star.ytn.co.kr/_sn/0117_202505091128555812
- 상태: 보도(1차)
- id: https://star.ytn.co.kr/_sn/0117_202505091128555812
- 메모: 예고/공지 성격. 본편 원링크 확보 시 교체 권장.

- 날짜: 2025-05-10
- 구분: 기타(기사/스틸)
- 행사명: <언젠가는 슬기로울 전공의생활> 관련 기사(사진/스틸 포함 가능)
- 주최/플랫폼: tvN / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=361830
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=361830

- 날짜: 2025-05-17
- 구분: 기타(기사/스틸)
- 행사명: <언젠가는 슬기로울 전공의생활> 관련 기사(사진/스틸 포함 가능)
- 주최/플랫폼: tvN / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=362628
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=362628

- 날짜: 2025-05-18
- 구분: 기타(기사/스틸)
- 행사명: <언젠가는 슬기로울 전공의생활> 관련 기사(사진/스틸 포함 가능)
- 주최/플랫폼: tvN / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=362734
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=362734

- 날짜: 2025-05-20
- 구분: 기타(기사/스틸)
- 행사명: <언젠가는 슬기로울 전공의생활> 관련 기사(사진/스틸 포함 가능)
- 주최/플랫폼: tvN / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=362920
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=362920

- 날짜: 2025-05-21
- 구분: 기타(기사/스틸)
- 행사명: <언젠가는 슬기로울 전공의생활> 관련 기사(사진/스틸 포함 가능)
- 주최/플랫폼: tvN / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=363033
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=363033

- 날짜: 2025-12-11
- 구분: 기타(기사/스틸)
- 행사명: <이 사랑 통역 되나요?> 관련 기사(사진/스틸 포함 가능)
- 주최/플랫폼: Netflix / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=387125
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=387125

## 2024
- 날짜: 2024-12-26
- 구분: 기타(기사/스틸)
- 행사명: <조명가게> 관련 기사/리뷰(사진/스틸 포함 가능)
- 주최/플랫폼: Disney+ / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=343890
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=343890

## 2023
- 날짜: 2023-08-03
- 구분: 제작발표회/포토타임
- 행사명: Disney+ 오리지널 시리즈 <무빙> 제작발표회
- 주최/플랫폼: Disney+ / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=274438
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=274438
- 메모: 행사 사진/현장 기록이 포함될 수 있는 보도 링크.

## 2022
- 날짜: 2022-07-28
- 구분: 시사회/포토타임
- 행사명: 영화 <헌트> 시사회(현장)
- 주최/플랫폼: 영화 헌트 / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=220920
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=220920
- 메모: 시사회 현장 사진/기록이 포함될 수 있는 보도 링크.

## 공식 링크
- (S) 과거 소속사(MAA) 프로필: https://maa.co.kr/artists/go-younjung

## 출처
- (S/A) 각 항목의 원문 URL(시상식 공식 페이지/공식 영상/1차 보도)
- 정책: docs/editorial_policy.md
