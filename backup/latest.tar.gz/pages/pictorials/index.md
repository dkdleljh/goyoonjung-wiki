# 📸 사진/화보 아카이브 (카테고리)


## 카테고리
- [커버/표지](cover.md)
- [에디토리얼/화보](editorial.md)
- [캠페인/룩북/브랜드 컷](campaign.md)
- [메이킹/비하인드/영상 스틸](making.md)
- [행사/포토월/시상식](events.md)
- [작품 스틸/포스터](stills-posters.md)

## 항목 템플릿
- 날짜: YYYY-MM-DD (또는 YYYY-MM)
- 매체/브랜드:
- 종류: 커버 | 에디토리얼 | 캠페인 | 메이킹
- 링크: (URL)
- 상태: 공식확정 | 공식예고 | 보도(1차) | 보도(2차)
- id: (URL)
- 간단 메모:

## 공식 링크
- (S) 과거 소속사(MAA) 프로필(기준): https://maa.co.kr/artists/go-younjung

## 출처
- pages/pictorials/* 각 항목의 원문 URL(매거진/브랜드 공식 페이지)
- 정책: docs/editorial_policy.md
