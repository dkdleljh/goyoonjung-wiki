# Vogue Korea

> 자동 후보 링크 페이지입니다. (키워드 매칭 기반)

> 갱신: 2026-10-18 12:21 (Asia/Seoul)

## 공식 링크

- (S) 과거 소속사(MAA) 프로필(기준): https://maa.co.kr/artists/go-younjung

- (A/S) https://www.vogue.co.kr/


## 출처

- (S/A) 각 후보 링크의 원문 URL(공식/1차 보도)

- (정책) docs/editorial_policy.md

<!-- AUTO-CANDIDATES:START -->
## 관련 링크(자동 후보)

- [현대적인 우아함, 고윤정의 샤넬](https://www.vogue.co.kr/2025/10/05/현대적인-우아함-고윤정의-샤넬/)  _(출처: interviews.md)_

- [고윤정, 보그코리아 화보..숙취해소 브랜드 모델](https://mbiz.heraldcorp.com/article/10496760?sec=014)  _(출처: interviews.md)_

- [이병헌-고윤정이 그려낼 조선 하드보일드 액션 ‘남벌’](https://www.vogue.co.kr/2026/07/07/%ec%9d%b4%eb%b3%91%ed%97%8c-%ea%b3%a0%ec%9c%a4%ec%a0%95%ec%9d%b4-%ea%b7%b8%eb%a0%a4%eb%82%bc-%ec%a1%b0%ec%84%a0-%ed%95%98%eb%93%9c%eb%b3%b4%ec%9d%bc%eb%93%9c-%ec%95%a1%ec%85%98-%eb%82%a8/)  _(출처: pictorials/editorial.md)_

- [고윤정이 마주한 새하얀 겨울](https://www.vogue.co.kr/2026/10/07/%ea%b3%a0%ec%9c%a4%ec%a0%95%ec%9d%b4-%eb%a7%88%ec%a3%bc%ed%95%9c-%ec%83%88%ed%95%98%ec%96%80-%ea%b2%a8%ec%9a%b8/)  _(출처: pictorials/editorial.md)_

- [Go ZERO, Now ZERO](https://www.vogue.co.kr/2025/05/26/go-zero-now-zero/)  _(출처: pictorials/editorial.md)_

- [고윤정 화보, '2030 여성들 워너비' 다운 남다른 스타일..물오른 여신 비주얼](http://www.breaknews.com/935054)  _(출처: pictorials/editorial.md)_

- [고윤정의 봄, 봄, 봄](https://www.vogue.co.kr/2022/02/21/%EA%B3%A0%EC%9C%A4%EC%A0%95%EC%9D%98-%EB%B4%84-%EB%B4%84-%EB%B4%84/)  _(출처: pictorials/editorial.md)_

- [부쉐론의 여신, 고윤정](https://www.vogue.co.kr/2022/08/26/%EB%B6%80%EC%89%90%EB%A1%A0%EC%9D%98-%EC%97%AC%EC%8B%A0-%EA%B3%A0%EC%9C%A4%EC%A0%95/)  _(출처: pictorials/editorial.md)_

- [한없이 투명에 가까운, 고윤정](https://www.vogue.co.kr/2021/02/17/%ED%95%9C%EC%97%86%EC%9D%B4-%ED%88%AC%EB%AA%85%EC%97%90-%EA%B0%80%EA%B9%8C%EC%9A%B4-%EA%B3%A0%EC%9C%A4%EC%A0%95/)  _(출처: pictorials/editorial.md)_

- [CHANEL / Vogue Korea](https://www.vogue.co.kr/2024/05/03/%EC%83%A4%EB%84%AC-%ED%81%AC%EB%A3%A8%EC%A6%88-2024-25-%EC%87%BC%EC%97%90-%EC%B0%B8%EC%84%9D%ED%95%9C-%EA%B3%A0%EC%9C%A4%EC%A0%95/)  _(출처: pictorials/campaign.md)_
<!-- AUTO-CANDIDATES:END -->
