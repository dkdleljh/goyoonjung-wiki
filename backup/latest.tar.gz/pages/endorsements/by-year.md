# 광고/엠버서더 — 연도별 인덱스

> 목적: 브랜드/광고/엠버서더 기록을 연도별로 빠르게 찾기 위한 인덱스입니다.
> 메모: ‘발표일/시작일’이 확인된 항목만 자동으로 포함됩니다.

---

## 2026
- [내셔널지오그래픽 어패럴](https://www.yna.co.kr/amp/view/AKR20260923185000030) — 모델/캠페인 출연
- [디디에 두보](https://news.nate.com/view/20260227n09186) — 모델/캠페인 출연 <!-- Broken/404: 2026-10-31 -->
- [젝시믹스](https://www.lawissue.co.kr/view.php?ud=202606041207144463204ead0791_12) — 모델/캠페인 출연

## 2025
- [디디에 두보(DIDIER DUBOT)](https://news.nate.com/view/20250825n17937) — 모델
- [한화손해보험](https://www.sisaon.co.kr/news/articleView.html?idxno=175918) — 브랜드 전속모델

## 2024
- [구달(goodal)](https://youtu.be/p3lwXW6nT5U) — 모델/뮤즈
- [보다나(VODANA)](https://youtu.be/hV1sOJLuMN8) — 뮤즈
- [상쾌환(EASY TOMORROW)](https://youtu.be/TrDLHYVJ4w8) — 모델
- [샤넬(CHANEL)](https://www.instagram.com/p/C6gW0vQNU1_/) — (앰버서더/프렌즈 여부 공식 확인 필요)
- [푸라닭치킨](https://youtu.be/NdogLAtlyys) — 모델

## 2023
- [LENSME(렌즈미)](https://youtu.be/aRrlD-9WIbk) — 뮤즈
- [디스커버리 익스페디션(Discovery Expedition)](https://youtu.be/ZH1Y1l1OmTY) — 모델
- [려(RYO)](https://youtu.be/dmS_nEQYv2I) — 글로벌 앰버서더
- [캐롯손해보험(캐롯자동차보험)](https://youtu.be/jXCnrLQJfzE) — 모델

## 2022
- [라타플랑(RATAPLAN)](https://rataplan.co.kr/article/%EB%A7%A4%EA%B1%B0%EC%A7%84/8/1157) — 뮤즈
- [마리떼 프랑소와 저버(MARITHÉ FRANÇOIS GIRBAUD)](https://youtu.be/76aAMPpCTb4) — 뮤즈

## 2019
- [SK텔레콤(SK Telecom)](https://www.idaegu.com/news/articleView.html?idxno=381461) — 모델

---
※ 이 페이지는 자동 생성됩니다. 원문은 각 카테고리 파일을 수정하세요.

## 공식 링크
- (S) 과거 소속사(MAA) 프로필(기준): https://maa.co.kr/artists/go-younjung

## 출처
- pages/endorsements/beauty.md
- pages/endorsements/fashion.md
- pages/endorsements/lifestyle.md
