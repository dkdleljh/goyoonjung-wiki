# 🤝 광고/엠버서더 — 뷰티/스킨케어/메이크업


## 템플릿
- 브랜드/회사명:
  - 카테고리:
  - 역할:
  - 발표일/시작일: YYYY-MM-DD (또는 YYYY)
  - 링크(공식 발표): (브랜드/기관/매체의 공식 발표 페이지)
  - 링크(공식 영상/캠페인): (YouTube/공식 사이트 캠페인)
  - 상태: 공식확정 | 공식예고 | 보도(1차)
  - id: (대표 URL 1개)
  - 비고:

---

## 목록
- 브랜드/회사명: 구달(goodal)
  - 카테고리: 뷰티
  - 역할: 모델/뮤즈
  - 발표일/시작일: 2024-02-27 (YouTube datePublished)
  - 링크(공식 발표): https://youtu.be/p3lwXW6nT5U (자동: 공식 채널 게시물로 대체)
  - 링크(공식 영상/캠페인): https://youtu.be/p3lwXW6nT5U
  - 상태: 공식확정
  - id: https://youtu.be/p3lwXW6nT5U
  - 비고: NamuWiki 참고로 공식 광고 영상 링크 확보(상세 발표일은 추후 공식 보도자료로 보강)

- 브랜드/회사명: 보다나(VODANA)
  - 카테고리: 뷰티
  - 역할: 뮤즈
  - 발표일/시작일: 2024-02-29
  - 링크(공식 발표): https://youtu.be/hV1sOJLuMN8 (자동: 공식 채널 게시물로 대체)
  - 링크(공식 영상/캠페인): https://youtu.be/hV1sOJLuMN8
  - 상태: 공식확정
  - id: https://youtu.be/hV1sOJLuMN8
  - 비고: 공식 광고 영상 링크

- 브랜드/회사명: 려(RYO)
  - 카테고리: 뷰티
  - 역할: 글로벌 앰버서더
  - 발표일/시작일: 2023-04-04 (YouTube datePublished)
  - 링크(공식 발표): https://youtu.be/dmS_nEQYv2I (자동: 공식 채널 게시물로 대체)
  - 링크(공식 영상/캠페인): https://youtu.be/dmS_nEQYv2I
  - 상태: 공식확정
  - id: https://youtu.be/dmS_nEQYv2I
  - 비고: 공식 광고 영상 링크

- 브랜드/회사명: 라타플랑(RATAPLAN)
  - 카테고리: 뷰티
  - 역할: 뮤즈
  - 발표일/시작일: 2022-12-01 (공식 게시글)
  - 링크(공식 발표): https://rataplan.co.kr/article/%EB%A7%A4%EA%B1%B0%EC%A7%84/8/1157
  - 링크(공식 영상/캠페인): (추가 보강 필요)
  - 상태: 공식확정
  - id: https://rataplan.co.kr/article/%EB%A7%A4%EA%B1%B0%EC%A7%84/8/1157
  - 비고: 공식 사이트 공지

## 공식 링크
- 구달(goodal) 공식 캠페인(YouTube): https://youtu.be/p3lwXW6nT5U
- 보다나(VODANA) 공식 캠페인(YouTube): https://youtu.be/hV1sOJLuMN8
- 려(RYO) 공식 캠페인(YouTube): https://youtu.be/dmS_nEQYv2I
- 라타플랑(RATAPLAN) 공식 공지: https://rataplan.co.kr/article/%EB%A7%A4%EA%B1%B0%EC%A7%84/8/1157

## 출처
- (S) YouTube 공식 채널 게시 메타(datePublished)
- (S) 브랜드 공식 사이트 공지(라타플랑)
