# 🤝 광고/엠버서더 — 라이프스타일/기타


## 템플릿
- 브랜드/회사명:
  - 카테고리:
  - 역할:
  - 발표일/시작일: YYYY-MM-DD (또는 YYYY)
  - 링크(공식 발표): (브랜드/기관/매체의 공식 발표 페이지)
  - 링크(공식 영상/캠페인): (YouTube/공식 사이트 캠페인)
  - 상태: 공식확정 | 공식예고 | 보도(1차)
  - id: (대표 URL 1개)
  - 비고:

---

## 목록
- 브랜드/회사명: 한화손해보험
  - 카테고리: 라이프스타일
  - 역할: 브랜드 전속모델
  - 발표일/시작일: 2025-09-29
  - 링크(공식 발표): https://www.sisaon.co.kr/news/articleView.html?idxno=175918
  - 링크(공식 영상/캠페인): (추가 보강 필요)
  - 상태: 공식확정
  - id: https://www.sisaon.co.kr/news/articleView.html?idxno=175918
  - 비고: 한화손보 새 브랜드 전속모델로 선정, '여성 웰니스 리딩 파트너' 브랜드 비전 발표

- 브랜드/회사명: 캐롯손해보험(캐롯자동차보험)
  - 카테고리: 라이프스타일
  - 역할: 모델
  - 발표일/시작일: 2023-07-31 (YouTube datePublished)
  - 링크(공식 발표): https://youtu.be/jXCnrLQJfzE (자동: 공식 채널 게시물로 대체)
  - 링크(공식 영상/캠페인): https://youtu.be/jXCnrLQJfzE
  - 상태: 공식확정
  - id: https://youtu.be/jXCnrLQJfzE
  - 비고: TVC 공식 영상

- 브랜드/회사명: 푸라닭치킨
  - 카테고리: 라이프스타일
  - 역할: 모델
  - 발표일/시작일: 2024-01-25 (YouTube datePublished)
  - 링크(공식 발표): https://youtu.be/NdogLAtlyys (자동: 공식 채널 게시물로 대체)
  - 링크(공식 영상/캠페인): https://youtu.be/NdogLAtlyys
  - 상태: 공식확정
  - id: https://youtu.be/NdogLAtlyys
  - 비고: 공식 광고 영상

- 브랜드/회사명: 상쾌환(EASY TOMORROW)
  - 카테고리: 라이프스타일
  - 역할: 모델
  - 발표일/시작일: 2024-04-07 (YouTube datePublished)
  - 링크(공식 발표): https://youtu.be/TrDLHYVJ4w8 (자동: 공식 채널 게시물로 대체)
  - 링크(공식 영상/캠페인): https://youtu.be/TrDLHYVJ4w8
  - 상태: 공식확정
  - id: https://youtu.be/TrDLHYVJ4w8
  - 비고: 공식 광고 영상

- 브랜드/회사명: NH농협은행(올원뱅크)
  - 카테고리: 라이프스타일
  - 역할: 모델
  - 발표일/시작일: 미상(공식 링크는 있으나 날짜 메타 자동 추출 실패)
  - 링크(공식 발표): https://youtu.be/c_VCPdtEA6A (자동: 공식 채널 게시물로 대체)
  - 링크(공식 영상/캠페인): https://youtu.be/c_VCPdtEA6A
  - 상태: 공식확정
  - id: https://youtu.be/c_VCPdtEA6A
  - 비고: 공식 영상

- 브랜드/회사명: LENSME(렌즈미)
  - 카테고리: 라이프스타일
  - 역할: 뮤즈
  - 발표일/시작일: 2023-08-02 (YouTube datePublished)
  - 링크(공식 발표): https://youtu.be/aRrlD-9WIbk (자동: 공식 채널 게시물로 대체)
  - 링크(공식 영상/캠페인): https://youtu.be/aRrlD-9WIbk
  - 상태: 공식확정
  - id: https://youtu.be/aRrlD-9WIbk
  - 비고: 공식 캠페인 영상

## 공식 링크
- 캐롯손해보험 TVC(YouTube): https://youtu.be/jXCnrLQJfzE
- 푸라닭치킨 TVC(YouTube): https://youtu.be/NdogLAtlyys
- 상쾌환(EASY TOMORROW) TVC(YouTube): https://youtu.be/TrDLHYVJ4w8
- NH농협은행(올원뱅크) 공식 영상(YouTube): https://youtu.be/c_VCPdtEA6A
- LENSME(렌즈미) 공식 캠페인(YouTube): https://youtu.be/aRrlD-9WIbk

## 출처
- (S) YouTube 공식 채널 게시 메타(datePublished)
