# 🤝 광고/엠버서더 — 패션/주얼리


## 템플릿
- 브랜드/회사명:
  - 카테고리:
  - 역할:
  - 발표일/시작일: YYYY-MM-DD (또는 YYYY)
  - 링크(공식 발표): (브랜드/기관/매체의 공식 발표 페이지)
  - 링크(공식 영상/캠페인): (YouTube/공식 사이트 캠페인)
  - 상태: 공식확정 | 공식예고 | 보도(1차)
  - id: (대표 URL 1개)
  - 비고:

---

## 목록
- 브랜드/회사명: SK텔레콤(SK Telecom)
  - 카테고리: 통신
  - 역할: 모델
  - 발표일/시작일: 2019-11
  - 링크(공식 발표): https://www.idaegu.com/news/articleView.html?idxno=381461
  - 링크(공식 영상/캠페인): (추가 필요)
  - 상태: 공식확정
  - id: https://www.idaegu.com/news/articleView.html?idxno=381461
  - 비고: 초기 광고 모델 활동

- 브랜드/회사명: 마리떼 프랑소와 저버(MARITHÉ FRANÇOIS GIRBAUD)
  - 카테고리: 패션
  - 역할: 뮤즈
  - 발표일/시작일: 2022-11-28 (YouTube datePublished)
  - 링크(공식 발표): https://youtu.be/76aAMPpCTb4 (자동: 공식 채널 게시물로 대체)
  - 링크(공식 영상/캠페인): https://youtu.be/76aAMPpCTb4
  - 상태: 공식확정
  - id: https://youtu.be/76aAMPpCTb4
  - 비고: 캠페인 영상(시즌별 영상은 추가로 누적)

- 브랜드/회사명: 디스커버리 익스페디션(Discovery Expedition)
  - 카테고리: 패션
  - 역할: 모델
  - 발표일/시작일: 2023-11-28 (YouTube datePublished)
  - 링크(공식 발표): https://youtu.be/ZH1Y1l1OmTY (자동: 공식 채널 게시물로 대체)
  - 링크(공식 영상/캠페인): https://youtu.be/ZH1Y1l1OmTY
  - 상태: 공식확정
  - id: https://youtu.be/ZH1Y1l1OmTY
  - 비고: 공식 캠페인 영상

- 브랜드/회사명: 샤넬(CHANEL)
  - 카테고리: 패션
  - 역할: (앰버서더/프렌즈 여부 공식 확인 필요)
  - 발표일/시작일: 2024-05-03 (공식 인스타 게시물)
  - 링크(공식 발표): https://www.instagram.com/p/C6gW0vQNU1_/ (자동: 공식 채널 게시물로 대체)
  - 링크(공식 영상/캠페인): https://www.instagram.com/p/C6gW0vQNU1_/
  - 상태: 공식확정
  - id: https://www.instagram.com/p/C6gW0vQNU1_/
  - 비고: 공식 계정 게시물(정확한 역할 명칭은 추후 공식 발표로 보강)

- 브랜드/회사명: 부쉐론(Boucheron)
  - 카테고리: 주얼리
  - 역할: 앰버서더
  - 발표일/시작일: 미상(공식 링크는 있으나 날짜 메타 자동 추출 실패)
  - 링크(공식 발표): https://www.instagram.com/p/CWvduIJt1P2/ (자동: 공식 채널 게시물로 대체)
  - 링크(공식 영상/캠페인): https://www.instagram.com/p/CWvduIJt1P2/
  - 상태: 공식확정
  - id: https://www.instagram.com/p/CWvduIJt1P2/
  - 비고: 공식 계정 게시물(다수 게시물은 추후 정리)

- 브랜드/회사명: 디디에 두보(DIDIER DUBOT)
  - 카테고리: 주얼리
  - 역할: 모델
  - 발표일/시작일: 2025-08
  - 링크(공식 발표): https://news.nate.com/view/20250825n17937 <!-- Broken/404: 2026-10-31 -->
  - 링크(공식 영상/캠페인): (추가 보강 필요)
  - 상태: 공식확정
  - id: https://news.nate.com/view/20250825n17937
  - 비고: 2025 FW '듀얼 디디(Dual D.D) 컬렉션' 광고 캠페인

## 공식 링크
- 샤넬(CHANEL) 공식 발표(Instagram): https://www.instagram.com/p/C6gW0vQNU1_/
- 부쉐론(Boucheron) 공식 발표(Instagram): https://www.instagram.com/p/CWvduIJt1P2/
- MARITHÉ FRANÇOIS GIRBAUD 공식 캠페인(YouTube): https://youtu.be/76aAMPpCTb4
- 디스커버리 익스페디션 공식 캠페인(YouTube): https://youtu.be/ZH1Y1l1OmTY

## 출처
- (S) 브랜드 공식 SNS/공식 채널 게시물(각 항목의 '링크(공식 발표)' 참조)
- (S) YouTube 공식 채널 게시 메타(datePublished)

- 브랜드/회사명: 젝시믹스
  - 카테고리: 패션/주얼리
  - 역할: 모델/캠페인 출연
  - 발표일/시작일: 2026-06-04 (보도·캠페인 기준)
  - 링크(공식 발표): https://www.lawissue.co.kr/view.php?ud=202606041207144463204ead0791_12
  - 상태: 보도(1차)
  - id: https://www.lawissue.co.kr/view.php?ud=202606041207144463204ead0791_12
  - 비고: 브랜드 모델 발탁 보도. UNDEFINE 캠페인.

- 브랜드/회사명: 내셔널지오그래픽 어패럴
  - 카테고리: 패션/주얼리
  - 역할: 모델/캠페인 출연
  - 발표일/시작일: 2026-09-25 (보도·캠페인 기준)
  - 링크(공식 발표): https://www.yna.co.kr/amp/view/AKR20260923185000030
  - 상태: 보도(1차)
  - id: https://www.yna.co.kr/amp/view/AKR20260923185000030
  - 비고: 코스토니 리버시블 플리스 광고 출연 보도일. 계약 시작일은 별도 확인 필요.

- 브랜드/회사명: 디디에 두보
  - 카테고리: 패션/주얼리
  - 역할: 모델/캠페인 출연
  - 발표일/시작일: 2026-02-27 (보도·캠페인 기준)
  - 링크(공식 발표): https://news.nate.com/view/20260227n09186 <!-- Broken/404: 2026-10-31 -->
  - 상태: 보도(1차)
  - id: https://news.nate.com/view/20260227n09186
  - 비고: 2026 SS 캠페인 공개일. 최초 뮤즈 계약일 아님.
