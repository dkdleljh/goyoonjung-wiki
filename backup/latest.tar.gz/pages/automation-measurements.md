# 자동 수집 실측

게시부터 최초 조회 지연은 날짜가 확인된 원문 표본만 계산하며 과거 자료도 포함합니다. 정확도·전체 자료 대비 수집률은 독립 정답 집합이 없어 미측정. 실행 성공률은 가동률이나 사실 정확도가 아님.

| 지표 | 실측 |
|---|---|
| publication_to_first_fetch_samples | 122 |
| publication_to_first_fetch_p50_seconds | 2173589.514156 |
| publication_to_first_fetch_p95_seconds | 19386683.24519 |
| sample_count | 176 |
| avg_execution_seconds | 23.64 |
| execution_p95_seconds | 32.8 |
| fast_run_success_percent | 4.02 |
| oldest_source_success_age_minutes | 160.1 |
| monitored_sources | 78 |
| recall | 미측정 |
| precision | 미측정 |
