# 자동 수집 실측

게시부터 최초 조회 지연은 날짜가 확인된 원문 표본만 계산하며 과거 자료도 포함합니다. 정확도·전체 자료 대비 수집률은 독립 정답 집합이 없어 미측정. 실행 성공률은 가동률이나 사실 정확도가 아님.

| 지표 | 실측 |
|---|---|
| publication_to_first_fetch_samples | 169 |
| publication_to_first_fetch_p50_seconds | 1799428.284359 |
| publication_to_first_fetch_p95_seconds | 19356886.990855 |
| sample_count | 745 |
| avg_execution_seconds | 26.06 |
| execution_p95_seconds | 38.12 |
| fast_run_success_percent | 0.95 |
| oldest_source_success_age_minutes | 155.0 |
| monitored_sources | 78 |
| recall | 미측정 |
| precision | 미측정 |
