# 자동 수집 실측

게시부터 최초 조회 지연은 날짜가 확인된 원문 표본만 계산하며 과거 자료도 포함합니다. 정확도·전체 자료 대비 수집률은 독립 정답 집합이 없어 미측정. 실행 성공률은 가동률이나 사실 정확도가 아님.

| 지표 | 실측 |
|---|---|
| publication_to_first_fetch_samples | 5 |
| publication_to_first_fetch_p50_seconds | 1798522.436621 |
| publication_to_first_fetch_p95_seconds | 2328265.784927 |
| sample_count | 8 |
| avg_execution_seconds | 40.09 |
| execution_p95_seconds | 191.15 |
| fast_run_success_percent | 57.14 |
| oldest_source_success_age_minutes | 25.5 |
| monitored_sources | 40 |
| recall | 미측정 |
| precision | 미측정 |
