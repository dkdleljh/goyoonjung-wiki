# 자동 수집 실측

게시부터 최초 조회 지연은 날짜가 확인된 원문 표본만 계산하며 과거 자료도 포함합니다. 정확도·전체 자료 대비 수집률은 독립 정답 집합이 없어 미측정. 실행 성공률은 가동률이나 사실 정확도가 아님.

| 지표 | 실측 |
|---|---|
| publication_to_first_fetch_samples | 268 |
| publication_to_first_fetch_p50_seconds | 29531.444679 |
| publication_to_first_fetch_p95_seconds | 14939969.494237 |
| sample_count | 2000 |
| avg_execution_seconds | 31.15 |
| execution_p95_seconds | 76.07 |
| fast_run_success_percent | 0.25 |
| oldest_source_success_age_minutes | 406.5 |
| monitored_sources | 77 |
| recall | 미측정 |
| precision | 미측정 |
