# Boucheron

> 자동 후보 링크 페이지입니다. (키워드 매칭 기반)

> 갱신: 2026-10-19 00:02 (Asia/Seoul)

## 공식 링크

- (S) 과거 소속사(MAA) 프로필(기준): https://maa.co.kr/artists/go-younjung

- (A/S) https://www.boucheron.com/


## 출처

- (S/A) 각 후보 링크의 원문 URL(공식/1차 보도)

- (정책) docs/editorial_policy.md

<!-- AUTO-CANDIDATES:START -->
## 관련 링크(자동 후보)

- [부쉐론의 여신, 고윤정](https://www.gqkorea.co.kr/2022/08/26/%eb%b6%80%ec%89%90%eb%a1%a0%ec%9d%98-%ec%97%ac%ec%8b%a0-%ea%b3%a0%ec%9c%a4%ec%a0%95/)  _(출처: interviews.md)_

- [SK텔레콤(SK Telecom)](https://www.idaegu.com/news/articleView.html?idxno=381461)  _(출처: endorsements/fashion.md)_

- [눈이 부시게 #HMBD 고윤정 X 부쉐론](https://www.marieclairekorea.com/celebrity/2023/03/boucheron-gohyoonjung/)  _(출처: pictorials/editorial.md)_

- [배우 고윤정, 부쉐론과 함께한 'EOY 캠페인' 홀리데이 화보 공개](https://www.rnx.kr/news/articleView.html?idxno=335348)  _(출처: pictorials/editorial.md)_

- [부쉐론의 여신, 고윤정](https://www.vogue.co.kr/2022/08/26/%EB%B6%80%EC%89%90%EB%A1%A0%EC%9D%98-%EC%97%AC%EC%8B%A0-%EA%B3%A0%EC%9C%A4%EC%A0%95/)  _(출처: pictorials/editorial.md)_

- [부쉐론의 여신, 고윤정](https://www.wkorea.com/2022/08/26/%eb%b6%80%ec%89%90%eb%a1%a0%ec%9d%98-%ec%97%ac%ec%8b%a0-%ea%b3%a0%ec%9c%a4%ec%a0%95/)  _(출처: pictorials/editorial.md)_

- [부쉐론의 여신, 고윤정](https://www.vogue.co.kr/2022/08/26/%eb%b6%80%ec%89%90%eb%a1%a0%ec%9d%98-%ec%97%ac%ec%8b%a0-%ea%b3%a0%ec%9c%a4%ec%a0%95/)  _(출처: pictorials/editorial.md)_

- [부쉐론과 고윤정이 창조한 미의 세계](https://www.vogue.co.kr/2022/09/02/%eb%b6%80%ec%89%90%eb%a1%a0%ea%b3%bc-%ea%b3%a0%ec%9c%a4%ec%a0%95%ec%9d%b4-%ec%b0%bd%ec%a1%b0%ed%95%9c-%eb%af%b8%ec%9d%98-%ec%84%b8%ea%b3%84/)  _(출처: pictorials/editorial.md)_
<!-- AUTO-CANDIDATES:END -->
