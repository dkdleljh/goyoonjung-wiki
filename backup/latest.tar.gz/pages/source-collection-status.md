# 수집 출처 상태

출처별 마지막 실제 확인 결과입니다. 새 자료 0건은 정상일 수 있지만, 접속·해석 실패는 성공으로 처리하지 않습니다.

전체 피드는 최근 기사 범위만 확인합니다. 과거 자료 전체를 검색했다는 뜻이 아닙니다.

retired는 근거를 확인해 정기 수집을 종료한 과거 출처입니다. 실제 수집 성공이 아니며 활성 출처의 성공·실패 집계에서 제외합니다. 확인 시각은 종료 정책 점검 시각입니다.

## agency

- 확인: 2026-11-22T00:03:55+09:00

| 출처 | 상태 | 범위 | 마지막 성공 | 연속 실패 | 상세 |
|---|---|---|---|---|---|
| [MAA 등록 프로필](https://maa.co.kr/artists/go-younjung) | retired | historical_profile | 없음 | 해당 없음 | MAA 흡수합병과 AAP 소속 보도를 확인해 과거 MAA 프로필의 정기 수집을 종료했다. 에이투지 공식 아티스트 소개에 고윤정이 없어 대체 프로필로 등록하지 않는다. · 수집 종료: 2026-10-18 · [근거 1](https://kind.krx.co.kr/external/2026/05/08/000634/20260428000456/71769.htm) · [근거 2](https://comp.nicebizline.com/co/CO0100M010GE.nice?nav=2&stockcd=291230) · [근거 3](http://a2zentertainment.co.kr/main/html.php?htmid=service/image9coms.html) · [근거 4](https://www.tenasia.co.kr/article/2026090158504) |

## archive

- 확인: 2026-11-23T00:41:04+09:00

| 출처 | 상태 | 범위 | 마지막 성공 | 연속 실패 | 상세 |
|---|---|---|---|---|---|
| [Allure Korea](https://www.allurekorea.com/wp-admin/admin-ajax.php) | success | historical pagination page 3 | 2026-11-16T02:45:26+09:00 | 0 | 확인 0건 · 관련 0건 |
| [Arena](https://www.arenakorea.com/rss/allArticle.xml) | success | historical pagination page 3 | 2026-11-16T05:45:24+09:00 | 0 | 확인 50건 · 관련 0건 |
| [Cosmopolitan Korea](https://www.cosmopolitan.co.kr/search) | success | historical pagination page 5 | 2026-11-16T08:45:30+09:00 | 0 | 확인 0건 · 관련 0건 |
| [ELLE Korea](https://www.elle.co.kr/search) | success | historical pagination page 6 | 2026-11-16T10:45:35+09:00 | 0 | 확인 0건 · 관련 0건 |
| [Esquire Korea](https://www.esquirekorea.co.kr/search) | success | historical pagination page 3 | 2026-11-16T03:45:27+09:00 | 0 | 확인 0건 · 관련 0건 |
| [GQ Korea](https://www.gqkorea.co.kr/wp-admin/admin-ajax.php) | success | historical pagination page 1 | 2026-11-23T00:41:04+09:00 | 0 | 확인 12건 · 관련 2건 |
| [Harper’s BAZAAR Korea](https://www.harpersbazaar.co.kr/search) | success | historical pagination page 8 | 2026-11-16T11:45:36+09:00 | 0 | 확인 0건 · 관련 0건 |
| [Marie Claire Korea](https://www.marieclairekorea.com/?s=%EA%B3%A0%EC%9C%A4%EC%A0%95&feed=rss2) | success | historical pagination page 7 | 2026-11-16T11:45:36+09:00 | 0 | 확인 0건 · 관련 0건 · Archive page 7 returns 404; current feed valid (10 items). Historical boundary is unconfirmed. |
| [Noblesse](https://noblesse.com/feed/) | success | historical pagination page 425 | 2026-11-23T00:41:04+09:00 | 0 | 확인 10건 · 관련 0건 |
| [Singles](https://www.singleskorea.com/api/article-search) | success | historical pagination page 2 | 2026-11-16T01:45:25+09:00 | 0 | 확인 0건 · 관련 0건 |
| [Vogue Korea](https://www.vogue.co.kr/feed/?s=%EA%B3%A0%EC%9C%A4%EC%A0%95) | success | historical pagination page 6 | 2026-11-16T09:45:32+09:00 | 0 | 확인 0건 · 관련 0건 · RSS media namespace declaration repaired; Archive page 6 returns 404; current feed valid (10 items). Historical boundary is unconfirmed. |
| [W Korea](https://www.wkorea.com/wp-admin/admin-ajax.php) | success | historical pagination page 3 | 2026-11-16T06:45:26+09:00 | 0 | 확인 0건 · 관련 0건 |

## magazines

- 확인: 2026-11-23T10:48:08+09:00

| 출처 | 상태 | 범위 | 마지막 성공 | 연속 실패 | 상세 |
|---|---|---|---|---|---|
| [Allure Korea](https://www.allurekorea.com/wp-admin/admin-ajax.php) | success | keyword_search | 2026-11-23T10:48:08+09:00 | 0 | 확인 20건 · 관련 8건 |
| [Arena](https://www.arenakorea.com/rss/allArticle.xml) | success | recent_feed | 2026-11-23T10:48:08+09:00 | 0 | 확인 50건 · 관련 0건 |
| [Cosmopolitan Korea](https://www.cosmopolitan.co.kr/search) | success | keyword_search | 2026-11-23T10:48:08+09:00 | 0 | 확인 18건 · 관련 8건 |
| [ELLE Korea](https://www.elle.co.kr/search) | success | keyword_search | 2026-11-23T10:48:08+09:00 | 0 | 확인 18건 · 관련 12건 |
| [Esquire Korea](https://www.esquirekorea.co.kr/search) | success | keyword_search | 2026-11-23T10:48:08+09:00 | 0 | 확인 18건 · 관련 3건 |
| [GQ Korea](https://www.gqkorea.co.kr/wp-admin/admin-ajax.php) | success | keyword_search | 2026-11-23T10:48:08+09:00 | 0 | 확인 12건 · 관련 2건 |
| [Harper’s BAZAAR Korea](https://www.harpersbazaar.co.kr/search) | success | keyword_search | 2026-11-23T10:48:08+09:00 | 0 | 확인 18건 · 관련 9건 |
| [Marie Claire Korea](https://www.marieclairekorea.com/?s=%EA%B3%A0%EC%9C%A4%EC%A0%95&feed=rss2) | success | keyword_search | 2026-11-23T10:48:08+09:00 | 0 | 확인 10건 · 관련 8건 |
| [Noblesse](https://noblesse.com/feed/) | success | recent_feed | 2026-11-23T10:48:08+09:00 | 0 | 확인 10건 · 관련 0건 |
| [Singles](https://www.singleskorea.com/api/article-search) | success | keyword_search | 2026-11-23T10:48:08+09:00 | 0 | 확인 6건 · 관련 2건 |
| [Vogue Korea](https://www.vogue.co.kr/feed/?s=%EA%B3%A0%EC%9C%A4%EC%A0%95) | success | keyword_search | 2026-11-23T10:48:08+09:00 | 0 | 확인 10건 · 관련 2건 · RSS media namespace declaration repaired |
| [W Korea](https://www.wkorea.com/wp-admin/admin-ajax.php) | success | keyword_search | 2026-11-23T10:48:08+09:00 | 0 | 확인 20건 · 관련 13건 |

## official-live

- 확인: 2026-11-23T18:51:21+09:00

| 출처 | 상태 | 범위 | 마지막 성공 | 연속 실패 | 상세 |
|---|---|---|---|---|---|
| [Boucheron](https://www.boucheron.com/) | failed | official search + original page | 없음 | 4024 | 확인 0건 · 관련 0건 · Index unavailable: HTTP 403 · 재시도 대기(최대 24시간); 마지막 실제 확인 결과 유지 |
| [CJ ENM](https://www.cjenm.com/ko/news/) | success | official search + original page | 2026-11-23T18:51:21+09:00 | 0 | 확인 0건 · 관련 0건 |
| [Chanel](https://www.chanel.com/) | failed | official search + original page | 없음 | 4024 | 확인 0건 · 관련 0건 · Index unavailable: HTTP 403 · 재시도 대기(최대 24시간); 마지막 실제 확인 결과 유지 |
| [Disney](https://thewaltdisneycompany.com/news/) | success | official search + original page | 2026-11-23T18:51:21+09:00 | 0 | 확인 0건 · 관련 0건 |
| [Goodal](https://clubclio.co.kr/shop/brandsList/121733000000000/brand/3) | success | official search + original page | 2026-11-23T18:51:21+09:00 | 0 | 확인 0건 · 관련 0건 |
| [JTBC](https://tv.jtbc.co.kr/) | success | official search + original page | 2026-11-23T18:51:21+09:00 | 0 | 확인 1건 · 관련 1건 |
| [Netflix](https://about.netflix.com/ko) | success | official search + original page | 2026-11-23T18:51:21+09:00 | 0 | 확인 1건 · 관련 0건 |
| [Penshoppe](https://www.penshoppe.com/) | success | official search + original page | 2026-11-23T18:51:21+09:00 | 0 | 확인 0건 · 관련 0건 |
| [TVING](https://www.tving.com/) | success | official search + original page | 2026-11-23T18:51:21+09:00 | 0 | 확인 0건 · 관련 0건 |
| [tvN](https://tvn.cjenm.com/ko/) | success | official search + original page | 2026-11-23T18:51:21+09:00 | 0 | 확인 1건 · 관련 0건 |
| [백상예술대상](https://www.baeksangawards.co.kr/) | success | official search + original page | 2026-11-23T18:51:21+09:00 | 0 | 확인 0건 · 관련 0건 |
| [청룡시리즈어워즈](https://bsa.blueaward.co.kr/) | failed | official search + original page | 2026-11-22T06:00:26+09:00 | 6 | 확인 0건 · 관련 0건 · Index unavailable: Connection timeout (5 seconds) |

## youtube

- 확인: 2026-11-23T18:51:12+09:00

| 출처 | 상태 | 범위 | 마지막 성공 | 연속 실패 | 상세 |
|---|---|---|---|---|---|
| [DisneyPlusKR](https://www.youtube.com/feeds/videos.xml?channel_id=UCtdz9LWNNQKUg4Xpma_40Ug) | success | recent_uploads_feed | 2026-11-23T18:51:12+09:00 | 0 | 확인 15건 · 관련 0건 |
| [JTBC Drama](https://www.youtube.com/feeds/videos.xml?channel_id=UCkbJc8jMcTXwhtmN5VMwfXg) | success | recent_uploads_feed | 2026-11-23T18:51:12+09:00 | 0 | 확인 15건 · 관련 0건 |
| [JTBCEntertainment](https://www.youtube.com/feeds/videos.xml?channel_id=UCFL1sCAksD6_7JIZwwHcwjQ) | success | recent_uploads_feed | 2026-11-23T18:51:12+09:00 | 0 | 확인 15건 · 관련 0건 |
| [MBCdrama](https://www.youtube.com/feeds/videos.xml?channel_id=UCBAEVMr0li9YYF8IwZHfusw) | success | recent_uploads_feed | 2026-11-23T18:51:12+09:00 | 0 | 확인 15건 · 관련 0건 |
| [MBCentertainment](https://www.youtube.com/feeds/videos.xml?channel_id=UCiBr0bK06imaMbLc8sAEz0A) | success | recent_uploads_feed | 2026-11-23T18:51:12+09:00 | 0 | 확인 15건 · 관련 0건 |
| [NetflixKorea](https://www.youtube.com/feeds/videos.xml?channel_id=UCpiCK8c6PBktcxq7Az_t4RQ) | success | recent_uploads_feed | 2026-11-23T18:51:12+09:00 | 0 | 확인 15건 · 관련 0건 |
| [SBSNOW](https://www.youtube.com/feeds/videos.xml?channel_id=UCcOYEm78CpaZQvPE6LtoSeA) | success | recent_uploads_feed | 2026-11-23T18:51:12+09:00 | 0 | 확인 15건 · 관련 0건 |
| [TEO](https://www.youtube.com/feeds/videos.xml?channel_id=UC-uIpGINZDL-VIHQQzJW8jw) | success | recent_uploads_feed | 2026-11-23T18:51:12+09:00 | 0 | 확인 15건 · 관련 0건 |
| [TVING](https://www.youtube.com/feeds/videos.xml?channel_id=UCNIiH_4ArJNd_cDZApZ7AFg) | success | recent_uploads_feed | 2026-11-23T18:51:12+09:00 | 0 | 확인 15건 · 관련 0건 |
| [tvN DRAMA](https://www.youtube.com/feeds/videos.xml?channel_id=UC9w-h_ciMmX64TcLRcb1xPg) | success | recent_uploads_feed | 2026-11-23T18:51:12+09:00 | 0 | 확인 15건 · 관련 0건 |
| [tvN Joy](https://www.youtube.com/feeds/videos.xml?channel_id=UC78PMQprrZTbU0IlMDsYZPw) | success | recent_uploads_feed | 2026-11-23T18:51:12+09:00 | 0 | 확인 15건 · 관련 0건 |
| [채널십오야](https://www.youtube.com/feeds/videos.xml?channel_id=UCQ2O-iftmnlfrBuNsUUTofQ) | success | recent_uploads_feed | 2026-11-23T18:51:12+09:00 | 0 | 확인 15건 · 관련 0건 |
