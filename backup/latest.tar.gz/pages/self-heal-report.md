# Self-Heal Report (auto)

> Updated: 2026-06-04 01:57 (Asia/Seoul)

## Summary
- actions: 12
- destructive_actions: 0

## Actions
| action | state | detail |
|---|---|---|
| run lock | ok | absent |
| notify queue | ok | flush_notify_queue: empty |
| quality report | ok | rebuild_quality_report: OK |
| verification queue | ok | rebuild_verification_queue: 22 items |
| official coverage | ok | official_coverage_audit: coverage_readiness=56 official_work_sync=85 |
| doc portals | ok |  |
| goyoonjung-wiki-daily.timer | ok | enabled |
| goyoonjung-wiki-sync.timer | ok | enabled |
| goyoonjung-wiki-linkhealth.timer | ok | enabled |
| goyoonjung-wiki-notifyflush.timer | ok | enabled |
| goyoonjung-wiki-backupcleanup.timer | ok | enabled |
| goyoonjung-wiki-watchdog.timer | ok | enabled |

## Safety
- git reset, force push, secret creation, mass deletion are intentionally not performed.
