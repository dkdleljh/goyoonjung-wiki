# Promotion Queue (auto)

> Updated: 2026-11-22 00:03 (Asia/Seoul)

## 대상(승격/정리 필요)
- 2026-02-16 · 보도(2차) 오래됨 → 공식/원문 승격 필요 · pages/appearances.md · https://www.sportschosun.com/entertainment/2026-02-16/202602160100103840007177
- 2026-06-15 · 보도(2차) 오래됨 → 공식/원문 승격 필요 · pages/interviews.md · https://enews.imbc.com/News/ViewAmp/508207
- 2026-10-12 · 보도(2차) 오래됨 → 공식/원문 승격 필요 · pages/filmography.md · https://news.jtbc.co.kr/article/NB12288396
- 2026-10-12 · 보도(2차) 오래됨 → 공식/원문 승격 필요 · pages/filmography.md · https://news.sbs.co.kr/news/endPage.do?news_id=N1008362847
- 2026-10-12 · 보도(2차) 오래됨 → 공식/원문 승격 필요 · pages/filmography.md · https://news.sbs.co.kr/news/endPage.do?news_id=N1008646839
- 2026-10-12 · 보도(2차) 오래됨 → 공식/원문 승격 필요 · pages/filmography.md · https://news.sbs.co.kr/news/endPage.do?news_id=N1008665295

## 도메인 A 등급 후보(자동 수집)
- 2026-11-20 · grade=A · OSEN · [류승룡·김무열·지창욱·황인엽·고윤정, ‘골든디스크’ 시상자 출격…하노이 달군다 - OSEN](http://www.osen.co.kr/article/G1112912789)
- 2026-11-05 · grade=A · WORKS · [고윤정, 한 손에 쌈 들고 오물오물…먹방 중에도 무결점 미모 - 매일경제](https://mk.co.kr/amp/12198087) <!-- Broken/404: 2026-11-22 -->
- 2026-10-20 · grade=A · 매일경제 · [고윤정 “‘무빙2’ 가슴 웅장해져...몸이 희수 기억” [화보] - 매일경제](https://mk.co.kr/amp/12180324) <!-- Broken/404: 2026-11-22 -->
- 2026-10-19 · grade=A · 매일경제 · [고윤정, 대학 시절부터 ‘얼굴 천재’...10년 전 포스터에 “역시 모세의 기적” [MK★이슈] - 매일경제](https://mk.co.kr/amp/12179279) <!-- Broken/404: 2026-11-22 -->
- 2026-10-19 · grade=A · 매일경제 · [“만석은 당연”…고윤정, 10년 전 대학축제 뒤집은 ‘미대 여신’ 시절 - 매일경제](https://mk.co.kr/amp/12179236) <!-- Broken/404: 2026-11-22 -->
- 2026-10-19 · grade=A · 세계일보 · [고윤정, 10년 전 대학 축제 주점 포스터 등장…이미 여신 비주얼 "당연히 만석" - 세계일보](https://segye.com/ampView/20261019503806)
- 2026-10-18 · grade=A · OSEN · [고윤정, 서울여대 모세의 기적 납득..주점 포스터 한장에 '성형설' 종결 [Oh!쎈 이슈] - OSEN](http://www.osen.co.kr/article/G1112894851)
- 2026-10-18 · grade=A · VARIETY_WORK · [내셔널지오그래픽, 허남준 모델 발탁…고윤정과 캠페인 영상 공개 - 아이뉴스24](http://www.inews24.com/view/2008864)
- 2026-10-18 · grade=A · FASHION · [고윤정, 파리에 화보 찍으러 갔나…막 찍어도 ‘레전드 미모’ - 매일경제](https://mk.co.kr/amp/12162117) <!-- Broken/404: 2026-11-22 -->
- 2026-10-12 · grade=A · AWARDS · [고윤정, 현시점 K-예쁨 대표 배우 [엔터포커싱] - 아이뉴스24](http://www.inews24.com/view/1991164)
