# OST/프로모션/티저/기타 영상 (MV 제외)


## 템플릿
- 날짜: YYYY-MM-DD
- 출처/채널:
- 구분: OST | 프로모션 | 티저 | 메이킹 | 인터뷰 | 기타
- 제목:
- 링크(원문):
- 상태: 공식확정 | 보도(1차) | 확인 필요
- id:
- 메모:

---

## 2026

(아직 추가된 항목이 없습니다.)

## 2025

(아직 추가된 항목이 없습니다.)

## 공식 링크
- (S) 과거 소속사(MAA) 프로필(기준): https://maa.co.kr/artists/go-younjung
- (A/S) 작품 공식 예고편/클립(YouTube, Netflix Korea/Disney+ Korea/tvN DRAMA 등 공식 채널)

## 출처
- (S/A) 각 항목의 원문 URL(공식 채널 업로드/공식 페이지)
- 정책: docs/editorial_policy.md
