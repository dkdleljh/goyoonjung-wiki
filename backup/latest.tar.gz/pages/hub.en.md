# 🧭 Go Youn-jung Wiki Hub

> Auto-generated hub · last updated: 2026-11-02

## Ops / Docs
- [Project README](../README.md)
- [Docs portal](../docs/README.md)
- [Operation guide](../docs/OPERATION_GUIDE.md)
- [Releasing guide](../docs/RELEASING.md)
- [CHANGELOG](../CHANGELOG.md)
- [System status](system_status.md)
- [Perfect Scorecard](perfect-scorecard.md)

## Status table
| 항목 | 값 |
|---|---|
| 최신 커밋 | `6e88744c5` |
| 최신 릴리즈 태그 | `v1.138.4` |
| docs 문서 수 | `21` |
| 운영 페이지 수 | `19` |
| 문서 생성기 | `scripts/generate_doc_portals.py` |
| daily update | `scripts/run_daily_update.sh` |

## Core content
- [Profile](profile.md)
- [Filmography](filmography.md)
- [Timeline](timeline.md)
- [Interviews](interviews.md)
- [Pictorials](pictorials.md)
- [Endorsements](endorsements.md)
- [Schedule](schedule.md)

## Recently changed files
- `data/facts/awards.json`
- `data/facts/evidence.json`
- `data/facts/profile.json`
- `data/facts/works.json`
- `data/reports/collectors/official-live.json`

## Ops pages
- [`pages/awards-official-watch.md`](awards-official-watch.md)
- [`pages/brand-evidence-watch.md`](brand-evidence-watch.md)
- [`pages/daily-report.md`](daily-report.md)
- [`pages/fact-conflicts.md`](fact-conflicts.md)
- [`pages/facts-index.md`](facts-index.md)
- [`pages/future-watch.md`](future-watch.md)
- [`pages/hub.en.md`](hub.en.md)
- [`pages/hub.md`](hub.md)
- [`pages/lint-report.md`](lint-report.md)
- [`pages/official-coverage-audit.md`](official-coverage-audit.md)
- [`pages/official-platform-watch.md`](official-platform-watch.md)
- [`pages/perfect-scorecard.md`](perfect-scorecard.md)
- [`pages/preflight-report.md`](preflight-report.md)
- [`pages/quality-report.md`](quality-report.md)
- [`pages/self-heal-report.md`](self-heal-report.md)
- [`pages/source-confidence.md`](source-confidence.md)
- [`pages/system_status.md`](system_status.md)
- [`pages/verification-queue.md`](verification-queue.md)
- [`pages/watchdog-report.md`](watchdog-report.md)
