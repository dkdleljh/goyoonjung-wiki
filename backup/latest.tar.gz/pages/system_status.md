# System status (auto)

> Updated: 2026-11-22

## wiki_completeness: **0/100**

placeholder debt score: debt=457
- (페이지 내 표기 확인 필요): 147
- (확인 필요): 279
- 검증불가: 13
- 교차검증 필요: 0
- 미확정: 2
- 요약 보강 필요: 0
- 참고(2차): 0
- 추가 필요: 3

## lint_clean: **100/100**

checked sections: clean

## link_health: **0/100**

checked at: 2026-11-22 00:03
counts: {'OK': 1116, 'WARN': 25, 'BAD': 5, 'UNCHECKED': 9}
score = verified OK / all discovered URLs; BAD forces zero

## automation_health: **0/100**

status: partial
last_run: 2026-11-22T00:05:00+09:00
age_hours: 0.01
source: news/2026-11-22.md
recorded_result: partial
reason: auto: done (indexes:OK,lint:OK,backup:goyoonjung-wiki_2026-11-22_0005.tar.gz), collect:OK, gnews:OK, gnews-sites:OK, gnews-queries:OK, mag-rss:OK, sched:OK, link-health:SKIP, portal-news:OK, san-news:OK, agency:RETIRED, ency:OK, promote-suggest:OK, lead-suggest:OK, awards-proof-suggest:OK, awards-proof-auto:OK, official-audit:OK, promote-safe:OK, endo-dates:OK, interview-sum:OK, work-candidates:OK, status-update:OK, visual:OK, dashboard:OK, RC_LINK:FAIL(1), mode:local-collection (not published)
max_age_hours: 8

## domain_grade_status

- S: 12
- A: 75
- B: 3
- BLOCK: 1

## kpi_snapshot

- new_urls: 0
- landed_urls: 0
- duplicate_rate: 23.53% (4/17)
- collected_urls_by_source_grade (fact verification is separate):
  - S: 0
  - A: 0
  - B: 0
