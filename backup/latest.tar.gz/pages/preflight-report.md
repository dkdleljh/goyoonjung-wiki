# Automation Preflight Report (auto)

> Updated: 2026-10-31 18:00 (Asia/Seoul)

## Summary
- status: WARN

## Checks
| check | state | detail |
|---|---|---|
| .venv/bin/python | OK | present |
| .venv/bin/ruff | OK | present |
| .venv/bin/bandit | OK | present |
| .venv/bin/pytest | OK | present |
| Discord webhook | OK | configured |
| disk free | OK | 55233 MiB |
| run lock | WARN | present |
| goyoonjung-wiki-daily.timer | WARN | no next run |
