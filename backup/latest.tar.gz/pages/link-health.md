# 링크 건강검진

> 갱신: 2026-11-22 06:00 (Asia/Seoul) · 대상 URL: 1157 (최대 100)

- OK: **1118** / WARN: **24** / BAD: **6** / UNCHECKED: **9**
- 검사 범위 밖 URL과 자동 접근을 생략한 URL은 정상으로 간주하지 않습니다.

## BAD (수정/교체 권장 — 404는 자동 태깅됨)

- (404) https://mk.co.kr/amp/12180324 · GET fallback
- (404) https://mk.co.kr/amp/12179236 · GET fallback (cached within 7 days)
- (404) https://mk.co.kr/amp/12162117 · GET fallback (cached within 7 days)
- (404) https://mk.co.kr/amp/12198087 · GET fallback (cached within 7 days)
- (404) https://www.yna.co.kr/entertainment · GET fallback (cached within 7 days)
- (404) https://mk.co.kr/amp/12179279 · GET fallback (cached within 7 days)

## WARN (차단/리다이렉트/확인 필요)

- (-) https://www.youtube.com/watch?v=oSBl3voJVn8 · Video metadata unavailable: HTTPError
- (-) https://daejong.or.kr/ · error: URLError
- (403) https://www.boucheron.com/ · GET fallback
- (403) https://www.armanibeauty.com/ · GET fallback (cached within 7 days)
- (-) https://slv.kstarfashion.com/news/articleView.html?idxno=214777 · error: URLError (cached within 7 days)
- (-) https://www.vodana.co.kr/ · error: URLError (cached within 7 days)
- (-) https://www.youtube.com/watch?v=nUMRPgOQfQE · Video metadata unavailable: HTTPError (cached within 7 days)
- (-) https://www.youtube.com/watch?v=1Fev1h1R3TU · Video metadata unavailable: HTTPError (cached within 7 days)
- (-) https://www.youtube.com/watch?v=HtFE5yr27mQ · Video metadata unavailable: HTTPError (cached within 7 days)
- (-) https://m.koreanfilm.or.kr/eng/films/index/filmsView.jsp?movieCd=20211792 · error: URLError (cached within 7 days)
- (-) https://www.youtube.com/watch?v=TmVnSCMrwqI · Video metadata unavailable: HTTPError (cached within 7 days)
- (-) https://www.youtube.com/watch?v=6iz4J7fb8RM · Video metadata unavailable: HTTPError (cached within 7 days)
- (-) https://www.youtube.com/watch?v=TfCfnCJprkg · Video metadata unavailable: HTTPError (cached within 7 days)
- (-) https://www.youtube.com/watch?v=GYBQ92_d4JU · Video metadata unavailable: HTTPError (cached within 7 days)
- (-) https://www.youtube.com/watch?v=gcRf8JuaHw8 · Video metadata unavailable: HTTPError (cached within 7 days)
- (-) https://www.lensme.co.kr/ · error: URLError (cached within 7 days)
- (-) https://www.youtube.com/watch?v=RuxvdOq_nuI · Video metadata unavailable: HTTPError (cached within 7 days)
- (-) https://www.easytomorrow.co.kr/ · error: URLError (cached within 7 days)
- (-) https://www.youtube.com/watch?v=4xQyMVgtIXQ · Video metadata unavailable: HTTPError (cached within 7 days)
- (-) https://www.youtube.com/watch?v=9xNJ2ZB5IuM · Video metadata unavailable: HTTPError (cached within 7 days)
- (-) https://www.disneypluskr.com/ · error: URLError (cached within 7 days)
- (-) https://www.youtube.com/watch?v=VFL9kEL90Qw · Video metadata unavailable: HTTPError (cached within 7 days)
- (500) https://segye.com/ampView/20261019503806 · GET fallback (cached within 7 days)
- (-) https://www.goodal.com/ · error: URLError (cached within 7 days)

## UNCHECKED (미검사)

- (-) https://www.instagram.com/p/C6gW0vQNU1_/ · social platform requires source-specific verification
- (-) https://www.instagram.com/p/CWvduIJt1P2/ · social platform requires source-specific verification
- (-) https://www.instagram.com/goyounjung/ · social platform requires source-specific verification
- (-) https://www.instagram.com/maakorea/ · social platform requires source-specific verification
- (-) https://maa.co.kr/artists/go-younjung · Retired historical agency; see config/agency-sources.json
- (-) https://www.allurekorea.com/wp-admin/admin-ajax.php · Read-only POST search API; validated by magazine collector, not a GET article (cached within 7 days)
- (-) https://www.gqkorea.co.kr/wp-admin/admin-ajax.php · Read-only POST search API; validated by magazine collector, not a GET article (cached within 7 days)
- (-) https://www.wkorea.com/wp-admin/admin-ajax.php · Read-only POST search API; validated by magazine collector, not a GET article (cached within 7 days)
- (-) https://maa.co.kr/ · Retired historical agency; see config/agency-sources.json (cached within 7 days)
