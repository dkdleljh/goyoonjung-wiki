# 🎤 방송/예능/행사(출연 기록)

![제3회 청룡시리즈어워즈에 참석한 고윤정](https://dkdleljh.github.io/goyounjung/images/photos/awards-559.webp)

## 한눈에 보기

- 한 줄 요약: 방송/예능/제작발표회/시사회 등 출연·행사 기록을 링크로 누적합니다.
- 핵심 링크: [연도별](appearances/by-year.md) · [타임라인](timeline.md)
- 상태: 공식/원문 근거 우선 · 행사/프로그램 단위로 누적

> 목적: 예능/유튜브/행사/시상식/제작발표회 등 ‘노출/홍보/등장’ 기록을 모읍니다.
> 원칙: 가능한 한 **공식 영상/공식 기사 링크**로 확인된 건만 기록합니다.

## 템플릿
- 날짜: YYYY-MM-DD
- 구분: 예능 | 유튜브 | 제작발표회 | 시상식 | 행사 | 기타
- 프로그램/행사명:
- 플랫폼/방송사:
- 링크(공식/원문):
- 상태: 공식확정 | 공식예고 | 보도(1차) | 보도(2차)
- id: (중복 방지 — URL)
- 메모: (공개된 정보만)

---

## 2026
- 날짜: 2026-07-31
- 구분: 방송/행사
- 프로그램/행사명: 제5회 청룡시리즈어워즈 레드카펫
- 플랫폼/방송사: iMBC연예
- 링크(공식/원문): https://enews.imbc.com/News/RetrieveNewsInfo/513316
- 상태: 보도(1차)
- id: https://enews.imbc.com/News/RetrieveNewsInfo/513316
- 메모: 기사 게시일 2026-08-01. 인천 파라다이스시티 레드카펫 참석을 확인했다. 이 자료만으로 수상 여부를 추정하지 않는다.

- 날짜: 2026-03-08
- 구분: 방송/행사
- 프로그램/행사명: 마니또 클럽 6회 출연 예고
- 플랫폼/방송사: iMBC연예
- 링크(공식/원문): https://enews.imbc.com/News/RetrieveNewsInfo/497002
- 상태: 공식예고
- id: https://enews.imbc.com/News/RetrieveNewsInfo/497002
- 메모: 기사 게시일 2026-03-07. MBC의 3월 8일 방송 예고에 고윤정이 포함됐다. 예고 자료임을 유지하며 실제 방송 여부의 별도 확인과 구분한다.

- 날짜: 2026-02-16
- 구분: 예능(방송 예고/리뷰)
- 프로그램/행사명: MBC <마니또 클럽> — 2기 출연진(고윤정 포함) 방송 말미 예고 언급
- 플랫폼/방송사: MBC / 스포츠조선
- 링크(공식/원문): https://www.sportschosun.com/entertainment/2026-02-16/202602160100103840007177
- 상태: 보도(2차)
- id: https://www.sportschosun.com/entertainment/2026-02-16/202602160100103840007177
- 메모: 3회 리뷰 기사. 방송 말미에 2기 출연진(정해인·고윤정 등) 예고가 담겼다고 서술.

- 날짜: 2026-02-10
- 구분: 예능(라인업 공개)
- 프로그램/행사명: MBC <마니또 클럽> — 2차 라인업(고윤정 포함) 공개
- 플랫폼/방송사: MBC / 디스패치
- 링크(공식/원문): https://www.dispatch.co.kr/2338820
- 상태: 보도(1차)
- id: https://www.dispatch.co.kr/2338820
- 메모: 기사 본문에서 ‘MBC-TV 마니또 클럽 측이 10일 추가 출연진을 공개’했다고 언급.

- 날짜: 2026-02-03
- 구분: 예능(출연 확정 보도)
- 프로그램/행사명: MBC <마니또 클럽> — 고윤정·김도훈 출연 확정(보도)
- 플랫폼/방송사: MBC / 마이데일리
- 링크(공식/원문): https://www.mydaily.co.kr/page/view/2026020313291419433
- 상태: 보도(1차)
- id: https://www.mydaily.co.kr/page/view/2026020313291419433
- 메모: ‘3일 마이데일리 취재 결과 … 출연을 확정’ 문구 기반.

- 날짜: 2026-01-22
- 구분: 예능(출연 보도)
- 프로그램/행사명: MBC <마니또 클럽> — 고윤정 출연(보도)
- 플랫폼/방송사: MBC / 스포티비뉴스
- 링크(공식/원문): https://www.spotvnews.co.kr/news/articleView.html?idxno=794454
- 상태: 보도(1차)
- id: https://www.spotvnews.co.kr/news/articleView.html?idxno=794454
- 메모: ‘22일 스포티비뉴스 취재에 따르면 … 출연’ 문구 기반. (기사에는 첫 방송 일정도 함께 기재)

- 날짜: 2026-01-14
- 구분: 제작발표회
- 프로그램/행사명: 넷플릭스 <이 사랑 통역 되나요?> 제작발표회
- 플랫폼/방송사: Netflix / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=389846
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=389846
- 메모: 보도(1차) 기반. Netflix 공식 포토/영상 링크 확보 시 상향.

---

> 메모: 항목을 추가할 때는 위 템플릿을 따르고, 링크는 `scripts/add_seen_url.sh`로 정규화 후 `sources/seen-urls.*`에 등록합니다.

- 날짜: 2026-02-22
- 구분: 기타(보도/홍보)
- 프로그램/행사명: '마니또 클럽' 고윤정, 나, 미대 나온 여자야~
- 플랫폼/방송사: KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=393465
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=393465
- 메모: 보도(1차). 사진/스틸 포함 가능.

- 날짜: 2026-03-09
- 구분: 기타(보도/홍보)
- 프로그램/행사명: 고윤정, 말간 얼굴의 ‘도끼 PD’ (JTBC ‘모두가 자신의 무가치함과 싸우고 있다’)
- 플랫폼/방송사: KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=394652
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=394652
- 메모: 보도(1차). 사진/스틸 포함 가능.

- 날짜: 2026-03-13
- 구분: 기타(보도/홍보)
- 프로그램/행사명: 고윤정도 싸우고 있다... JTBC 드라마 모두가 자신의 무가치함과...
- 플랫폼/방송사: KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=395293
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=395293
- 메모: 보도(1차). 사진/스틸 포함 가능.

- 날짜: 2026-03-26
- 구분: 기타(보도/홍보)
- 프로그램/행사명: '무가치함과 싸우고 있는' 구교환-고윤정.. 파워 포스터
- 플랫폼/방송사: KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=396661
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=396661
- 메모: 보도(1차). 사진/스틸 포함 가능.

- 날짜: 2026-03-31
- 구분: 기타(보도/홍보)
- 프로그램/행사명: 고윤정이 싸우는 무가치함... 도끼 PD의 머릿속엔 무엇이 있나?
- 플랫폼/방송사: KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=397104
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=397104
- 메모: 보도(1차). 사진/스틸 포함 가능.

- 날짜: 2026-04-21
- 구분: 기타(보도/홍보)
- 프로그램/행사명: 고윤정이 만들어드립니다... 제대로 싸우지 않던데요
- 플랫폼/방송사: KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=399141
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=399141
- 메모: 보도(1차). 사진/스틸 포함 가능.

- 날짜: 2026-07-08
- 구분: 기타(보도/홍보)
- 프로그램/행사명: 고윤정의 무협, 하드보일드 액션 '남벌' 캐스팅
- 플랫폼/방송사: KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=405372
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=405372
- 메모: 보도(1차). 사진/스틸 포함 가능.

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: 고윤정 OTT·스크린 넘나드는 활약 예고 - JTBC
- 링크(원문): https://news.jtbc.co.kr/article/NB12308062
- 상태: 보도(1차)
- id: https://news.jtbc.co.kr/article/NB12308062
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: 고윤정, 영화 '남벌' 캐스팅…이병헌과 첫 연기 호흡 - SBS 뉴스
- 링크(원문): https://news.sbs.co.kr/news/endPage.do?news_id=N1008646839
- 상태: 보도(1차)
- id: https://news.sbs.co.kr/news/endPage.do?news_id=N1008646839
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: ‘모자무싸’ 고윤정, 수식어 필요없는 압도적 비주얼 - JTBC
- 링크(원문): https://news.jtbc.co.kr/article/NB12294742
- 상태: 보도(1차)
- id: https://news.jtbc.co.kr/article/NB12294742
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: ‘모자무싸’ 고윤정 “박해영 작가가 나를 써주다니…영광이고 신기해” - JTBC
- 링크(원문): https://news.jtbc.co.kr/article/NB12294664
- 상태: 보도(1차)
- id: https://news.jtbc.co.kr/article/NB12294664
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: 이도현, '남벌' 캐스팅…이병헌·고윤정과 무협 액션 - SBS 뉴스
- 링크(원문): https://news.sbs.co.kr/news/endPage.do?news_id=N1008665295
- 상태: 보도(1차)
- id: https://news.sbs.co.kr/news/endPage.do?news_id=N1008665295
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: "김선호에 많이 배워"·"고윤정 센스 있고 성격 좋아"…'이 사랑 통역 되나요?' 빛나는 커플 케미 - SBS 뉴스
- 링크(원문): https://news.sbs.co.kr/news/endPage.do?news_id=N1008402330
- 상태: 보도(1차)
- id: https://news.sbs.co.kr/news/endPage.do?news_id=N1008402330
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: 고윤정, '무빙 시즌2' 이어 '남벌'까지…OTT와 스크린 넘나든다 - SBS 뉴스
- 링크(원문): https://news.sbs.co.kr/news/endPage.do?news_id=N1008655003
- 상태: 보도(1차)
- id: https://news.sbs.co.kr/news/endPage.do?news_id=N1008655003
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: "오로라 두 번 본 기적"…김선호♥고윤정 '이 사랑 통역 되나요?', 홍자매 로맨스 또 통할까 - SBS 뉴스
- 링크(원문): https://news.sbs.co.kr/news/endPage.do?news_id=N1008402376
- 상태: 보도(1차)
- id: https://news.sbs.co.kr/news/endPage.do?news_id=N1008402376
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: ‘모자무싸’ 고윤정, 예리한 눈빛의 영화사 PD 변신 - JTBC
- 링크(원문): https://news.jtbc.co.kr/article/NB12288396
- 상태: 보도(1차)
- id: https://news.jtbc.co.kr/article/NB12288396
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: 통역사 김선호♥톱스타 고윤정의 설레는 로맨스…'이 사랑 통역 되나요?', 포스터X예고편 공개 - SBS 뉴스
- 링크(원문): https://news.sbs.co.kr/news/endPage.do?news_id=N1008373667
- 상태: 보도(1차)
- id: https://news.sbs.co.kr/news/endPage.do?news_id=N1008373667
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: 드디어 공개된 구교환·고윤정 투샷…‘모자무싸’ 포스터 - JTBC
- 링크(원문): https://news.jtbc.co.kr/article/NB12291543
- 상태: 보도(1차)
- id: https://news.jtbc.co.kr/article/NB12291543
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: ‘이 사랑 통역 되나요’ 김선호 “고윤정 보며 설렌 적? 당연히 있죠” - JTBC
- 링크(원문): https://news.jtbc.co.kr/article/NB12281326
- 상태: 보도(1차)
- id: https://news.jtbc.co.kr/article/NB12281326
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: ‘이 사랑 통역 되나요?’ 바라만 봐도 설레는 김선호·고윤정 - JTBC
- 링크(원문): https://news.jtbc.co.kr/article/NB12276427
- 상태: 보도(1차)
- id: https://news.jtbc.co.kr/article/NB12276427
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: ‘이사통’ 김선호 “고윤정, 성격 정말 좋다…촬영 중 실수도 유쾌하게 넘어가” - JTBC
- 링크(원문): https://news.jtbc.co.kr/article/NB12279720
- 상태: 보도(1차)
- id: https://news.jtbc.co.kr/article/NB12279720
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: 리센느 제나 "추구미=고윤정, 얼굴 예쁜데 목소리는 중저음" - JTBC
- 링크(원문): https://news.jtbc.co.kr/article/NB12314528
- 상태: 보도(1차)
- id: https://news.jtbc.co.kr/article/NB12314528
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: 고윤정, ‘모자무싸’로 인생 캐릭터 경신 - JTBC
- 링크(원문): https://news.jtbc.co.kr/article/NB12294929
- 상태: 보도(1차)
- id: https://news.jtbc.co.kr/article/NB12294929
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: ‘모자무싸’ 고윤정, 시청자 응원 부른 불안과 결핍의 새 얼굴 - JTBC
- 링크(원문): https://news.jtbc.co.kr/article/NB12299711
- 상태: 보도(1차)
- id: https://news.jtbc.co.kr/article/NB12299711
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: 김선호X고윤정 로코 '이 사랑 통역 되나요?', 1월 16일 공개 확정 - SBS 뉴스
- 링크(원문): https://news.sbs.co.kr/news/endPage.do?news_id=N1008362847
- 상태: 보도(1차)
- id: https://news.sbs.co.kr/news/endPage.do?news_id=N1008362847
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: 우즈, '남벌'로 스크린 데뷔…이병헌·고윤정과 연기 호흡 - SBS 뉴스
- 링크(원문): https://news.sbs.co.kr/news/endPage.do?news_id=N1008670658
- 상태: 보도(1차)
- id: https://news.sbs.co.kr/news/endPage.do?news_id=N1008670658
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: ‘모자무싸’ 구교환·고윤정·배종옥, 숨 막히는 삼자대면… 밝혀질 비밀은 - JTBC
- 링크(원문): https://news.jtbc.co.kr/article/NB12299569
- 상태: 보도(1차)
- id: https://news.jtbc.co.kr/article/NB12299569
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: 고윤정 “‘이사통’ 김선호 보고 설렌 적? 분명 있었을 텐데…” - JTBC
- 링크(원문): https://news.jtbc.co.kr/article/NB12281561
- 상태: 보도(1차)
- id: https://news.jtbc.co.kr/article/NB12281561
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: 김선호·고윤정 ‘이 사랑 통역 되나요?’, 1월 16일 넷플릭스 공개 - JTBC
- 링크(원문): https://news.jtbc.co.kr/article/NB12274544
- 상태: 보도(1차)
- id: https://news.jtbc.co.kr/article/NB12274544
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: ‘프리랜서 몸값 150배’ 김대호 "10년째 연애 NO, 이상형 고윤정" - JTBC
- 링크(원문): https://news.jtbc.co.kr/article/NB12304140
- 상태: 보도(1차)
- id: https://news.jtbc.co.kr/article/NB12304140
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: 구교환X고윤정, '나의 아저씨' 작가 신작으로 뭉친다 - SBS 뉴스
- 링크(원문): https://news.sbs.co.kr/news/endPage.do?news_id=N1008410876
- 상태: 보도(1차)
- id: https://news.sbs.co.kr/news/endPage.do?news_id=N1008410876
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반

- 날짜: (페이지 내 표기 확인 필요)
- 구분: 출연/행사(공식 기사 후보)
- 제목: 고윤정, 매거진 표지 장식한 미모 "실망시키고 싶지 않아" - JTBC
- 링크(원문): https://news.jtbc.co.kr/article/NB12323835
- 상태: 보도(1차)
- id: https://news.jtbc.co.kr/article/NB12323835
- 메모: (자동 후보) 방송사/OTT 공식 도메인 기반
## 공식 링크
- (S) 과거 소속사(MAA) 프로필(필모/공식 활동): https://maa.co.kr/artists/go-younjung
- (A/S) YouTube(tvN/Netflix/Disney+ Korea 등 공식 채널) 링크는 항목별 `링크(공식/원문)`에 기록

## 출처
- (S) MAA 아티스트 프로필
- (A) 방송사/플랫폼 공식 채널 업로드(YouTube datePublished)
- (A) 1차 보도(원문) 링크(KBS연예 등)


## 2025
- 날짜: 2025-12-11
- 구분: 기타(작품/홍보)
- 프로그램/행사명: 넷플릭스 <이 사랑 통역 되나요?> 관련 보도
- 플랫폼/방송사: Netflix / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=387125
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=387125
- 메모: 작품 프로모션 보도(사진/스틸 포함 가능).

- 날짜: 2025-05-01
- 구분: 예능(하이라이트)
- 프로그램/행사명: 유 퀴즈 온 더 블럭 (YOU QUIZ ON THE BLOCK) — 고윤정 출연 하이라이트
- 플랫폼/방송사: tvN (YouTube)
- 링크(공식/원문): https://www.youtube.com/watch?v=TiTWX_KfEc0
- 상태: 공식확정
- id: https://www.youtube.com/watch?v=TiTWX_KfEc0
- 메모: 공식 업로드/하이라이트 영상 기준. 전체 방송 회차 정보는 추후 공식 페이지로 교차확인.

- 날짜: 2025-05-09
- 구분: 유튜브(라이브 예고/공지)
- 프로그램/행사명: 채널십오야 라이브 방송 출격(기사 기반 공지)
- 플랫폼/방송사: 채널 십오야 / 보도
- 링크(공식/원문): https://star.ytn.co.kr/_sn/0117_202505091128555812
- 상태: 보도(1차)
- id: https://star.ytn.co.kr/_sn/0117_202505091128555812
- 메모: 실제 라이브/본편 유튜브 원링크는 추후 확보하여 S급으로 교체 권장.

- 날짜: 2025-05-10
- 구분: 기타(작품/홍보)
- 프로그램/행사명: <언젠가는 슬기로울 전공의생활> 관련 보도(사진/스틸 포함 가능)
- 플랫폼/방송사: tvN / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=361830
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=361830

- 날짜: 2025-05-17
- 구분: 기타(작품/홍보)
- 프로그램/행사명: <언젠가는 슬기로울 전공의생활> 관련 보도(사진/스틸 포함 가능)
- 플랫폼/방송사: tvN / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=362628
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=362628

- 날짜: 2025-05-18
- 구분: 기타(작품/홍보)
- 프로그램/행사명: <언젠가는 슬기로울 전공의생활> 관련 보도(사진/스틸 포함 가능)
- 플랫폼/방송사: tvN / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=362734
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=362734

- 날짜: 2025-05-20
- 구분: 기타(작품/홍보)
- 프로그램/행사명: <언젠가는 슬기로울 전공의생활> 관련 보도/인터뷰(사진/스틸 포함 가능)
- 플랫폼/방송사: tvN / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=362920
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=362920

- 날짜: 2025-05-21
- 구분: 기타(작품/홍보)
- 프로그램/행사명: <언젠가는 슬기로울 전공의생활> 관련 보도(사진/스틸 포함 가능)
- 플랫폼/방송사: tvN / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=363033
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=363033

## 2024
- 날짜: 2024-12-26
- 구분: 기타(작품/홍보)
- 프로그램/행사명: Disney+ <조명가게> 관련 보도/리뷰
- 플랫폼/방송사: Disney+ / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=343890
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=343890
- 메모: 보도(1차) 기반. Disney+ 공식 링크 확보 시 상향.

- 날짜: 2024-07-19
- 구분: 시상식
- 프로그램/행사명: 제3회 청룡시리즈어워즈
- 플랫폼/방송사: 청룡시리즈어워즈(공식)
- 링크(공식/원문): https://bsa.blueaward.co.kr/bbs/board.php?bo_table=bsa_awards&history_no=3
- 상태: 공식확정
- id: https://bsa.blueaward.co.kr/bbs/board.php?bo_table=bsa_awards&history_no=3
- 메모: 행사 일시는 공식 HISTORY 페이지 기준. 수상/부문 상세는 `pages/awards.md`에 반영.

## 2023
- 날짜: 2023-08-03
- 구분: 제작발표회
- 프로그램/행사명: Disney+ 오리지널 시리즈 <무빙> 제작발표회
- 플랫폼/방송사: Disney+ / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=274438
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=274438
- 메모: KBS연예 보도 기반. Disney+ Korea 공식 포토/영상 링크 확보 시 상향.

- 날짜: 2023-08-24
- 구분: 기타(인터뷰/홍보)
- 프로그램/행사명: [인터뷰] 고윤정은 달린다 응원할게, 너 (디즈니+ ‘무빙’)
- 플랫폼/방송사: Disney+ / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=277651
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=277651
- 메모: 인터뷰 보도(사진 포함 가능).

## 2022
- 날짜: 2022-07-28
- 구분: 행사(시사회/포토타임)
- 프로그램/행사명: 영화 <헌트> 시사회(현장)
- 플랫폼/방송사: 영화 헌트 / KBS연예
- 링크(공식/원문): https://kstar.kbs.co.kr/list_view.html?idx=220920
- 상태: 보도(1차)
- id: https://kstar.kbs.co.kr/list_view.html?idx=220920
- 메모: 시사회 현장 보도(사진 포함 가능).

## 2021

(아직 추가된 항목이 없습니다.)

## 2020

(아직 추가된 항목이 없습니다.)

## 2019

(아직 추가된 항목이 없습니다.)
