# 🔎 Watchlist (매일 확인할 출처 목록)


## 사용 방법(매일)
- `news/YYYY-MM-DD.md`에 아래 목록을 복사해 체크(✅/—)로 남기세요.
- 새 출처를 발견하면 이 파일에 먼저 추가한 뒤, `sources/sources.md`에도 접근일과 함께 기록합니다.

---

## 소속사/공식
- MAA 공식 사이트: https://maa.co.kr/
- MAA 아티스트(고윤정) 프로필: https://maa.co.kr/artists/go-younjung

## OTT/방송사(공식)
- Netflix(공식/보도자료/회사소식): https://about.netflix.com/
- Netflix(검색: 고윤정): https://www.netflix.com/search?q=%EA%B3%A0%EC%9C%A4%EC%A0%95
- Disney+(KR, 공식): https://www.disneypluskr.com/
- Disney+(작품: 무빙): https://www.disneyplus.com/ko-kr/browse/entity-44e36964-f5f2-4c67-a2b0-aa3d609fc856
- tvN 공식: https://tvn.cjenm.com/ko/
  - (작품) 언젠가는 슬기로울 전공의생활(공식): https://tvn.cjenm.com/ko/resident-playbook/
- JTBC 공식: https://www.jtbc.co.kr/
- TVING 공식: https://www.tving.com/
- Wavve 공식: https://www.wavve.com/
- KBS 뉴스: https://news.kbs.co.kr/
- MBC 뉴스: https://imnews.imbc.com/
- SBS 뉴스: https://news.sbs.co.kr/
- JTBC 뉴스: https://news.jtbc.co.kr/

## 시상식(공식)
- 백상예술대상: https://www.baeksangawards.co.kr/
- 청룡시리즈어워즈: https://bsa.blueaward.co.kr/
- 청룡영화상: http://www.blueaward.co.kr/
- 대종상영화제: https://daejong.or.kr/

## 매거진/화보(공식)
- ELLE Korea(검색: 고윤정): https://www.elle.co.kr/?s=%EA%B3%A0%EC%9C%A4%EC%A0%95
- Vogue Korea(검색: 고윤정): https://www.vogue.co.kr/?s=%EA%B3%A0%EC%9C%A4%EC%A0%95
- Harper’s BAZAAR Korea(검색: 고윤정): https://www.harpersbazaar.co.kr/?s=%EA%B3%A0%EC%9C%A4%EC%A0%95
- Harper’s BAZAAR Korea(검색: 고윤정): https://www.harpersbazaar.co.kr/?s=%EA%B3%A0%EC%9C%A4%EC%A0%95
- Harper’s BAZAAR Korea(태그: 고윤정 화보): https://www.harpersbazaar.co.kr/tag/%EA%B3%A0%EC%9C%A4%EC%A0%95%20%ED%99%94%EB%B3%B4
- Marie Claire Korea(태그: 고윤정): https://www.marieclairekorea.com/tag/%EA%B3%A0%EC%9C%A4%EC%A0%95/
- Marie Claire Korea(패션 검색): https://www.marieclairekorea.com/?s=%EA%B3%A0%EC%9C%A4%EC%A0%95
- W Korea(검색: 고윤정): https://www.wkorea.com/?s=%EA%B3%A0%EC%9C%A4%EC%A0%95
- GQ Korea(검색: 고윤정): https://www.gqkorea.co.kr/?s=%EA%B3%A0%EC%9C%A4%EC%A0%95
- Esquire Korea(검색: 고윤정): https://www.esquirekorea.co.kr/?s=%EA%B3%A0%EC%9C%A4%EC%A0%95
- Cosmopolitan Korea(검색: 고윤정): https://www.cosmopolitan.co.kr/search?query=%EA%B3%A0%EC%9C%A4%EC%A0%95

## SNS(공식)
- MAA Instagram: https://www.instagram.com/maakorea/

## SNS(교차확인 필요)
- 고윤정 Instagram: https://www.instagram.com/goyounjung/  (MAA/공식 인터뷰 등에서 공식 표기 확인 후 '공식'으로 승격)

## 위키/백과(참고/2차)
- 위키백과(ko): https://ko.wikipedia.org/wiki/%EA%B3%A0%EC%9C%A4%EC%A0%95
- 나무위키: https://namu.wiki/w/%EA%B3%A0%EC%9C%A4%EC%A0%95

## 팬 커뮤니티(공식 여부 확인 필요)
- (추정) 공식 팬카페(다음 카페): https://cafe.daum.net/goyounjung.fans
  - 무인 수집: 로그인/권한/동적 로딩 이슈가 있을 수 있어 '변경 신호(접속/리다이렉트/헤더)'만 감지
  - 공식 확정: 소속사(MAA)나 공식 인터뷰/프로필에서 공식 팬카페로 링크/명시 확인 시 '공식'으로 승격

## 유튜브(공식 채널)
- 채널 십오야(나영석 관련 콘텐츠 업로드): https://www.youtube.com/channel/UCQ2O-iftmnlfrBuNsUUTofQ
- (참고) 나영석의 나불나불/와글와글 플레이리스트(검색/목록): https://www.youtube.com/playlist?list=PLr0T5CaHaPwVWLdtQIwORp6OT6hlvfVAN

## 주요 언론/매거진(대량 수집용)
- 상세 목록 및 사이트별 검색 링크 모음: `sources/media-watch.md`
- 브랜드/캠페인(공식 채널 고정 확인): `sources/brands-watch.md`

(매일 9시 업데이트 시에는 위 파일을 참고해 ‘많이 수집 → 잘 분류’ 흐름으로 정리합니다.)
